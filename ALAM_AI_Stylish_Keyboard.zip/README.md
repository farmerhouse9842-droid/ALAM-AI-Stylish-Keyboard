# ALAM AI Stylish Keyboard v1.2

One-ZIP GitHub Actions Android source project. Extracted by the one-time bootstrap workflow `.github/workflows/android.yml`.

Features: red neon default theme, additional color themes, photo background, glow strength, keyboard height, font size, optional vibration, Banglish transliteration, Bengali and English keys, Android speech-recognition intent for Bengali and English voice typing, emoji picker, number pad for numeric fields, local favorite phone numbers.

USSD-specific functionality is not included. Password/PIN fields suppress favorite and voice shortcuts. No PIN storage.

Limitations: voice recognition needs a compatible Android recognition service; may require internet. AI cloud rewrite/reply, fully functional fancy font conversion, GIF and advanced animations are not implemented. No subscription locks. No APK has been compiled in this environment.

First time: place the workflow file in the repository at `.github/workflows/android.yml`, then upload only `ALAM_AI_Stylish_Keyboard.zip` at the repository root. Subsequent updates replace that ZIP. Download APK from GitHub Actions artifacts after a successful build.
