ALAM AI Stylish Keyboard v1.3

Default Portrait Fire theme uses the user supplied portrait. Red glowing pressed keys, toolbar, English/Banglish/Bengali modes, Android speech recognizer, favorite numbers, themes, and photo picker. No USSD feature. AI cloud rewrite is not implemented; the sparkle button currently offers local quick replies.

To build via one-ZIP workflow: install .github/workflows/android.yml in the GitHub repository ONCE, then upload ALAM_AI_Stylish_Keyboard.zip at repository root. Subsequent updates replace only that ZIP. APK compilation not verified in this environment.

## v1.4 update
Added lightweight neon halo drawing and 190ms on-tap lightning flash, configurable in Settings. Low RAM mode disables animation. Not a continuously animated fire background. Android APK compilation has not been verified locally.


Version 1.5: Shared ValueAnimator drives animated glowing key outlines and moving ember sparks. Individual key press triggers a short lightning pulse. Settings: ambient_fire, animation_speed, fire_lightning, glow, low_ram. Animations stop when keyboard closes. Low RAM mode disables ambient and press animation. This is a lightweight stylized fire effect, not photorealistic flames. Build must be verified on GitHub Actions.
