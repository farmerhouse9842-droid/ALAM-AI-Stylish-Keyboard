# ALAM AI Stylish Keyboard — v1

A starter Android Input Method Editor (IME), built with Kotlin.

## Features implemented
- Keyboard activation and selection from Android settings.
- English basic QWERTY and simple Bengali character layout (not phonetic conversion).
- Automatic number keypad when the app marks its field as numeric/phone/date-time.
- Local favorite recipient numbers (tap star to insert; tap saved entry in settings to delete).
- Dark, Light, Neon, Glass, 3D color themes; user photo from Android document picker and opacity slider.
- No INTERNET permission; no PIN saving, keystroke logging, or network transmission.

## Limitations
- Some banking apps and USSD dialogs use custom input fields or block third-party keyboards. Numeric detection cannot be guaranteed there.
- AI rewriting, phonetic Bengali, emoji/GIF, voice typing, and cloud services are not implemented in this first build.
- Theme labels describe basic visual approximations, not advanced 3D/glass rendering.
- Favorite numbers are stored locally in app preferences, not encrypted; do not store PINs, OTPs, passwords or other secrets.
- This project is source code; the APK is produced by GitHub Actions. Debug APK is for testing.

## GitHub single ZIP upload
1. Upload `ALAM_AI_Stylish_Keyboard.zip` **and** `.github/workflows/android.yml` to repository root. GitHub does not automatically extract ZIP files; workflow extracts the ZIP during build.
2. In Actions, run `Build Android APK` (or push to main).
3. Download APK from workflow artifacts.

Alternatively, extract this ZIP and upload the full project to the repository root, including `.github`.

## v1.1 update
- Globe key cycles English -> Banglish -> Bengali.
- Banglish phonetic conversion works offline. Known words use dictionary mappings; unknown words use approximate conversion and may need correction.
- All implemented themes and photo backgrounds are free, with no premium paywall.
- Online AI rewrite/reply, GIFs, stickers and full dictionary-grade phonetic prediction are **not implemented**. No paid third-party service has been unlocked.
- Numeric keyboard is based on Android input field type; USSD and banking apps may restrict third-party IMEs.
- PIN/OTP/password storage is intentionally unsupported.


## One ZIP replacement workflow
The only file you need to replace for subsequent builds is `ALAM_AI_Stylish_Keyboard.zip`.
A NEW GitHub repository needs a one-time bootstrap workflow at `.github/workflows/android.yml`, because GitHub cannot discover a workflow buried inside a ZIP. The workflow is also included in this archive for users who extract the project instead.
Build is not verified locally; use Actions to confirm.
