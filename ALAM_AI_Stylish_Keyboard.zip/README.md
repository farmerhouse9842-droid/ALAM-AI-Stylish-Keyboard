# ALAM AI Stylish Keyboard v2.0

Single ZIP Android Kotlin source project for the existing GitHub one-ZIP workflow.

## Features in source
- Portrait Fire background, neon glowing keys, ambient animation and touch lightning
- English, Bangla and offline Banglish phonetic typing
- English and Banglish suggestion strips (limited local word lists)
- Android speech-recognition intent for Bangla and English (device service required)
- Themes, custom photo, key sound, vibration, low-RAM and animation settings
- Numeric fields, favorite phone numbers, emoji and selected-text fancy fonts
- Offline AI-toolbar quick replies and basic selected-text rewrite presets

## Important limitations
The rewrite presets are simple offline templates, not cloud AI. No external AI API is configured. Full predictive language models and pixel-identical 3D fire effects are not implemented. Banking PINs and OTPs are not stored. Some secure fields and apps may use their own keyboard.

## Build
Upload this ZIP as `ALAM_AI_Stylish_Keyboard.zip` to the existing GitHub repository with its one-time bootstrap workflow. GitHub Actions builds a debug APK. The source was statically inspected and ZIP integrity checked, but an Android SDK compile has not been run locally.

## v2.1
- Cached suggestion dictionaries to avoid rebuilding large lists on every keystroke.
- Offline text tools now accurately labeled as text transforms: uppercase, lowercase, sentence case, and final punctuation. These are NOT cloud AI.
- Existing themes, animation, voice recognition, numeric mode and Banglish preserved.
- No PIN or password storage.
- Build is not locally verified; run the GitHub Actions workflow to compile.


## Version 2.2 changes
- Clipboard now offers explicit Paste / Clear options instead of inserting clipboard content immediately.
- Better reset of suggestion state when switching fields, adding punctuation, or pressing Enter.
- Typing suggestions update after text is committed rather than before.
- Extra offline quick replies; these are templates, not cloud AI.
- Key animation disabled on secure input fields.

## Limitations
No cloud AI backend is included. Build and device QA must be performed using GitHub Actions and a physical Android device.


## v2.3 visual refinement
- Default Portrait Fire background now has a darkness slider for clearer personal photo.
- Keys have an additional glossy upper highlight and dark lower edge for a stronger 3D appearance.
- Bold key legends and mode-aware initial suggestions.
- Existing ambient ember, tap lightning, Bengali/English speech entry, Banglish, emoji, clipboard and favorite numbers retained.

**Limitations:** Cloud AI and full predictive dictionary are not implemented. GIF/sticker search is not implemented. Voice typing requires a speech recognizer on the phone. This project has not been compiled on a device in this environment.


## v2.4 verification notes
- Portrait Fire remains the default theme, with photo icon, moving ember border and touch lightning.
- English/Banglish/Bengali modes, Android speech recognition, numeric field layout, photo themes, offline suggestions and favorite numbers are present in source.
- Double-space punctuation is optional; numeric pad no longer includes USSD-specific star/hash keys.
- AI toolbar is **offline templates/text tools**, not cloud AI. GIF/sticker search and complete predictive language model are not implemented.
- Requires a GitHub Actions Android build and on-device testing before claiming production readiness.


## v2.5 correctness fixes
- Portrait dim overlay now uses explicit ARGB alpha instead of bitwise precedence.
- Symbols layout includes a dedicated delete key and ABC return key.
- Ambient animation is disabled in secure fields even if a previous field enabled it.
- All previous source and user portrait assets are retained.
- GitHub Actions compilation and on-device visual checks remain required.


## v2.6 additions
- Explicit Bengali/English voice language preference (Auto/বাংলা/English).
- Optional personal suggestion word list, saved only on user request.
- More robust clipboard access and decimal-aware numeric layout.
- No cloud AI is bundled: it requires a secure backend and explicit user consent.
- Existing Fire/Lightning animations remain; exact visual parity with concept artwork is not guaranteed.
- Build not validated locally; use the existing GitHub Actions workflow.

## Version 2.8
- Suggestions now inspect the current editor word instead of relying only on keystrokes from this keyboard; this improves suggestions after cursor movement and pasting.
- Numeric keypad now has a long-press repeat-delete key and respects decimal/signed field flags.
- Protected input fields still hide suggestions and favorites.
- Offline templates are not a cloud AI service. APK build and device behavior remain unverified locally.

## v2.9 update
- Shift now updates key labels and returns to lowercase after a single uppercase letter.
- Double-tap Shift to toggle Caps Lock; the shift key displays a lock arrow.
- Existing theme, voice typing, Banglish, favorites, and animation source retained.
- Build and device testing are still required.


## v3.0 incremental changes
- Spring-back keypress animation alongside the existing neon flash.
- Expanded offline emoji picker.
- Corrected version metadata and settings label.
- Previous portrait background, animated glow, phonetic typing, speech recognition, and favorites preserved.

### Still not complete
- No cloud AI: it needs an independently deployed backend and provider credentials.
- No full-size language model/predictive dictionary or pixel-identical animated reference rendering.
- Local Android SDK compile and device testing were not available in this environment.

## v3.1 changes and limitations
- Added five explicit offline text-rewrite templates to the AI toolbar (requires user-selected text).
- Increased animated neon ember count from three to five.
- These templates are deterministic, **not** cloud AI or semantic rewriting.
- No cloud AI service or backend credentials are bundled. Secure opt-in backend integration remains future work.
- This source ZIP has been structurally checked, but no Android SDK build or on-device test has been performed in this environment.

## v3.2 Theme gallery
- Added 10 visual color preview tiles in Settings, with tap-to-apply theme selection.
- Preserved Portrait Fire default, user photo, neon effects, offline typing, speech integration, and previous functionality.
- Visual preview tiles are simplified swatches, not live keyboard renderings.
- Cloud AI and full predictive model remain unimplemented; no internet permission or credentials are included.
- ZIP integrity checked, but Android compile and device QA are still required.


## v3.3 update
- Theme toolbar opens an in-keyboard quick theme chooser with 11 available themes.
- Theme selection is persisted immediately and keyboard layout refreshes without restarting the app.
- Advanced theme settings entry opens the existing settings screen.
- No USSD-specific features added.
- Cloud AI and full predictive typing remain unimplemented; do not describe this as fully complete.


## v3.4
Added limited context-based next-word suggestions for English and Banglish. Suggestions are processed on-device and never sent to a server. Cloud AI is not included. APK compilation and device testing remain necessary.


## v3.5 Unicode typing reliability
- Backspace now deletes a whole Unicode code point, preventing half-deleted emoji and supplementary characters.
- Password input detection remains protected, with secure fields disabling suggestion/clipboard/AI toolbar.
- Existing theme, animation, Banglish, voice, and number features retained.
- Cloud AI is not implemented; it requires an explicitly consented backend.
- Source ZIP checked; Android SDK compilation and on-device QA have not been completed here.

## Version 3.6
- Long-press number row keys for punctuation symbols.
- Long-press comma for punctuation popup.
- Version metadata updated.
- These are offline typing shortcuts; cloud AI is not implemented.


## v3.7 privacy update
- Clipboard preview is no longer exposed in the popup menu; paste remains opt-in.
- Input fields requesting no personalized learning are treated as private: suggestions, clipboard shortcuts, and AI shortcuts are hidden.
- Temporary Banglish composition state is cleared when the keyboard view closes.
- Source ZIP checked for integrity; Android compilation and device testing are not claimed.


## v3.8 reliability update
- Fixed invalid quote literal in punctuation popup that prevented Kotlin compilation.
- Added more contextual offline suggestions.
- Hide toolbar in numeric fields and avoid portrait imagery in protected fields.
- All existing source modules and image assets retained.
- Cloud AI is NOT implemented: it needs a secure server and provider credentials.
- The source ZIP has been integrity-checked, but an APK build/device test has not been performed.

## v3.9 changes
- Collapsible toolbar (hidden by default), language and microphone accessible on compact bar.
- Emoji category picker with scrollable multi-row emoji grid.
- Expanded direct Bengali character layout and Banglish punctuation protection.
- Android APK compilation not verified locally.


## Theme update v4.1
Added Rainbow RGB (animated hue), Electric Blue, Purple Glass, AMOLED and White alongside existing themes. Each has its own key fill, outline and keyboard background. Theme gallery and quick switcher updated. No subscription locks.

Build status: ZIP structure verified; Android compilation and device tests are not verified.

## v4.5 updates
- Keypress popup preview appears directly above the touched key (configurable in Settings > Key popup on keypress).
- Theme-specific glossy depth shading added to Red Neon/Portrait Fire, Rainbow RGB, Electric Blue, Purple Glass, Gold, Green Matrix, and 3D keys.
- Previous keyboard layouts, portrait background, voice typing, and single-ZIP GitHub workflow preserved.
- Requires GitHub Actions APK build and real-device testing; not claimed as fully verified.


2026-11-19 update: Bengali digits on top row; shorter Bengali letter keys (default 46dp, configurable via bangla_key_height); extra symbol page 2/2; Bengali dictionary suggestions and single-edit spelling alternatives. Suggestions are tap-to-accept rather than automatic replacement. Banking keyboard retains large keys.


## V4 visual refresh
Retains V3 Bangla digits, symbols, suggestions, banking keypad and voice typing. Portrait Fire and Red Neon keys now have deeper ruby-glass gradients, softer corners, stronger edge contrast, and a slightly darker portrait overlay for better key legibility.
