package com.alam.aikeyboard

/** Offline, approximate Banglish phonetic transliteration. No typed text leaves the device. */
object Banglish {
 private val dictionary = mapOf(
  "apnake" to "আপনাকে", "amader" to "আমাদের", "tomader" to "তোমাদের", "shob" to "সব", "sob" to "সব", "kichu" to "কিছু", "kisu" to "কিছু", "kintu" to "কিন্তু", "keno" to "কেনো", "kokhon" to "কখন", "kothao" to "কোথাও", "kivabe" to "কীভাবে", "kemne" to "কেমনে", "jodi" to "যদি", "tahole" to "তাহলে", "bujhi" to "বুঝি", "bujhlam" to "বুঝলাম", "bujhte" to "বুঝতে", "chao" to "চাও", "chai" to "চাই", "chilo" to "ছিল", "chole" to "চলে", "cholo" to "চলো", "chinta" to "চিন্তা", "dorkar" to "দরকার", "dibo" to "দিব", "dibe" to "দেবে", "dilen" to "দিলেন", "dite" to "দিতে", "doya" to "দয়া", "ekta" to "একটা", "eita" to "এইটা", "evabe" to "এভাবে", "ghor" to "ঘর", "ghum" to "ঘুম", "ghumao" to "ঘুমাও", "hocche" to "হচ্ছে", "hoise" to "হয়েছে", "hoyechhe" to "হয়েছে", "jante" to "জানতে", "jani" to "জানি", "jano" to "জানো", "jibon" to "জীবন", "kaj" to "কাজ", "kaje" to "কাজে", "kajer" to "কাজের", "karon" to "কারণ", "khobor" to "খবর", "khushi" to "খুশি", "lagbe" to "লাগবে", "lagche" to "লাগছে", "lage" to "লাগে", "likhe" to "লিখে", "mone" to "মনে", "mon" to "মন", "moja" to "মজা", "notun" to "নতুন", "purono" to "পুরোনো", "proyojon" to "প্রয়োজন", "somoy" to "সময়", "shomoy" to "সময়", "sotti" to "সত্যি", "thakbe" to "থাকবে", "thaki" to "থাকি", "thako" to "থাকো", "thik" to "ঠিক", "thikache" to "ঠিক আছে", "tobe" to "তবে", "abar" to "আবার", "ajke" to "আজকে", "agami" to "আগামী", "ratri" to "রাত্রি", "shokal" to "সকাল", "bikel" to "বিকেল", "shondha" to "সন্ধ্যা", "ami" to "আমি", "amra" to "আমরা", "amar" to "আমার", "amake" to "আমাকে", "tumi" to "তুমি", "tomar" to "তোমার", "tomake" to "তোমাকে", "apni" to "আপনি", "apnar" to "আপনার", "valo" to "ভালো", "bhalo" to "ভালো", "achi" to "আছি", "acho" to "আছো", "achen" to "আছেন", "kemon" to "কেমন", "ki" to "কি", "kee" to "কী", "korcho" to "করছো", "koro" to "করো", "kori" to "করি", "korbo" to "করবো", "hobe" to "হবে", "hoy" to "হয়", "na" to "না", "ha" to "হ্যাঁ", "haa" to "হ্যাঁ", "hya" to "হ্যাঁ", "ekhon" to "এখন", "aj" to "আজ", "kal" to "কাল", "sonar" to "সোনার", "bangla" to "বাংলা", "bangladesh" to "বাংলাদেশ", "valobashi" to "ভালোবাসি", "bhalobashi" to "ভালোবাসি", "dhonnobad" to "ধন্যবাদ", "assalamualaikum" to "আসসালামু আলাইকুম", "salam" to "সালাম", "vai" to "ভাই", "bhai" to "ভাই", "bon" to "বোন", "bari" to "বাড়ি", "basha" to "বাসা", "basa" to "বাসা", "kotha" to "কথা", "kothay" to "কোথায়", "jabo" to "যাবো", "jabe" to "যাবে", "jao" to "যাও", "aso" to "আসো", "asbo" to "আসবো", "khabo" to "খাবো", "khawa" to "খাওয়া", "pani" to "পানি", "khub" to "খুব", "sundor" to "সুন্দর", "onek" to "অনেক", "onk" to "অনেক", "bondhu" to "বন্ধু", "taka" to "টাকা", "number" to "নম্বর", "nam" to "নাম", "name" to "নাম", "likho" to "লিখো", "likhi" to "লিখি", "dao" to "দাও", "daw" to "দাও", "dekh" to "দেখ", "dekho" to "দেখো", "eta" to "এটা", "ota" to "ওটা", "seta" to "সেটা", "jeta" to "যেটা", "ekhane" to "এখানে", "okhane" to "ওখানে", "shuvo" to "শুভ", "shubho" to "শুভ", "rat" to "রাত", "din" to "দিন", "sokal" to "সকাল", "dupure" to "দুপুরে", "please" to "প্লিজ", "sorry" to "সরি", "hello" to "হ্যালো", "hi" to "হাই"
 )
 private val consonants = listOf("ksh" to "ক্ষ", "ng" to "ং", "chh" to "ছ", "kh" to "খ", "gh" to "ঘ", "ch" to "চ", "jh" to "ঝ", "th" to "থ", "dh" to "ধ", "ph" to "ফ", "bh" to "ভ", "sh" to "শ", "ss" to "ষ", "rr" to "ড়", "k" to "ক", "g" to "গ", "c" to "ক", "j" to "জ", "t" to "ত", "d" to "দ", "n" to "ন", "p" to "প", "f" to "ফ", "b" to "ব", "m" to "ম", "r" to "র", "l" to "ল", "s" to "স", "h" to "হ", "y" to "য়", "w" to "ও", "z" to "জ", "v" to "ভ", "q" to "ক", "x" to "ক্স")
 private val vowels = listOf("aa" to ("আ" to "া"), "ee" to ("ঈ" to "ী"), "ii" to ("ঈ" to "ী"), "oo" to ("ঊ" to "ূ"), "ou" to ("ঔ" to "ৌ"), "oi" to ("ঐ" to "ৈ"), "au" to ("ঔ" to "ৌ"), "a" to ("আ" to "া"), "i" to ("ই" to "ি"), "u" to ("উ" to "ু"), "e" to ("এ" to "ে"), "o" to ("ও" to "ো"))
 fun convert(word: String): String {
  dictionary[word.lowercase()]?.let { return it }
  if(word.isBlank() || word.any { !it.isLetter() }) return word
  val s=word.lowercase(); val out=StringBuilder(); var i=0; var previousConsonant=false
  while(i<s.length) {
   val vowel=vowels.firstOrNull { s.startsWith(it.first,i) }
   if(vowel!=null) {
    if(previousConsonant) { if(vowel.first!="a") out.append(vowel.second.second) }
    else out.append(vowel.second.first)
    previousConsonant=false; i+=vowel.first.length; continue
   }
   val cons=consonants.firstOrNull { s.startsWith(it.first,i) }
   if(cons!=null) {
    if(previousConsonant) out.append('্')
    out.append(cons.second); previousConsonant=true; i+=cons.first.length; continue
   }
   out.append(s[i]); previousConsonant=false; i++
  }
  return out.toString()
 }
}
