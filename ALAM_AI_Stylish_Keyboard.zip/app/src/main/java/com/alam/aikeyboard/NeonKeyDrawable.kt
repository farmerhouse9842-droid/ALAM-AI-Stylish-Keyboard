package com.alam.aikeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.PixelFormat
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.PI

/** Lightweight, hardware-accelerated-friendly neon border with brief lightning on key press. */
class NeonKeyDrawable(private val accent:Int, private val light:Boolean, private val glow:Int):Drawable() {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    var phase:Float=0f
        set(value) { field=value; invalidateSelf() }
    var animated:Boolean=false
    var pulse:Float=0f
        set(value) { field=value.coerceIn(0f,1f); invalidateSelf() }
    override fun draw(canvas:Canvas) {
        val b=bounds
        if(b.isEmpty) return
        val d=canvas.density.coerceAtLeast(1f)
        val r=12f*d
        val rect=RectF(b.left+3f*d,b.top+3f*d,b.right-3f*d,b.bottom-3f*d)
        paint.style=Paint.Style.FILL
        paint.color=if(light) 0xffedf0f5.toInt() else 0xe508080b.toInt()
        canvas.drawRoundRect(rect,r,r,paint)
        val strength=(glow/100f).coerceIn(0f,1f)
        // Translucent strokes simulate a halo without costly blur masks.
        for(i in 3 downTo 1) {
            paint.style=Paint.Style.STROKE
            paint.strokeWidth=(i*1.5f+strength*2f+pulse*3f)*d
            paint.color=accent
            paint.alpha=((16+strength*24+pulse*28)/i).toInt().coerceIn(0,255)
            canvas.drawRoundRect(rect,r,r,paint)
        }
        paint.strokeWidth=(1.25f+strength*.9f+pulse*1.8f)*d
        paint.alpha=(175+80*pulse).toInt().coerceIn(0,255)
        canvas.drawRoundRect(rect,r,r,paint)
        if(pulse>0.05f) {
            val x=rect.left+rect.width()*.18f
            val y=rect.top
            val w=min(rect.width()*.36f,27f*d)
            val path=Path().apply {
                moveTo(x,y); lineTo(x+w*.44f,y+rect.height()*.17f)
                lineTo(x+w*.25f,y+rect.height()*.17f)
                lineTo(x+w,y+rect.height()*.43f)
            }
            paint.color=Color.WHITE
            paint.alpha=(220*pulse).toInt().coerceIn(0,255)
            paint.strokeWidth=(1.5f+2f*pulse)*d
            paint.strokeCap=Paint.Cap.ROUND
            canvas.drawPath(path,paint)
        }
        if(animated) {
            val t=phase*2f*PI.toFloat()
            // Three moving ember sparks on the perimeter. No bitmap allocation per frame.
            val perimeter=2f*(rect.width()+rect.height())
            for(i in 0..2) {
                val pos=((phase+i/3f)%1f)*perimeter
                val px:Float; val py:Float
                when {
                    pos<rect.width() -> { px=rect.left+pos;py=rect.top }
                    pos<rect.width()+rect.height() -> { px=rect.right;py=rect.top+pos-rect.width() }
                    pos<2f*rect.width()+rect.height() -> { px=rect.right-(pos-rect.width()-rect.height());py=rect.bottom }
                    else -> { px=rect.left;py=rect.bottom-(pos-2f*rect.width()-rect.height()) }
                }
                val flicker=(0.6f+0.4f*sin(t+i*2.1f)).coerceIn(.1f,1f)
                paint.style=Paint.Style.FILL
                paint.color=if(i==0) Color.WHITE else 0xffff4b0a.toInt()
                paint.alpha=(160*flicker*strength).toInt().coerceIn(0,255)
                canvas.drawCircle(px,py,(1.8f+2.1f*flicker)*d,paint)
            }
            paint.style=Paint.Style.STROKE
            paint.strokeWidth=(1.2f+0.7f*sin(t).coerceAtLeast(0f))*d
            paint.color=accent
            paint.alpha=(110+75*sin(t).coerceAtLeast(0f)).toInt()
            canvas.drawRoundRect(rect,r,r,paint)
        }
        paint.alpha=255
    }
    override fun setAlpha(alpha:Int) { invalidateSelf() }
    override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) { paint.colorFilter=colorFilter; invalidateSelf() }
    @Deprecated("Deprecated in Java") override fun getOpacity()=PixelFormat.TRANSLUCENT
}
