package com.alam.aikeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.PixelFormat
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.PI

/** Lightweight, hardware-accelerated-friendly neon border with brief lightning on key press. */
class NeonKeyDrawable(private val accent:Int, private val light:Boolean, private val glow:Int, private val themeName:String="Portrait Fire"):Drawable() {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    var phase:Float=0f
        set(value) { field=value; invalidateSelf() }
    var animated:Boolean=false
    var pulse:Float=0f
        set(value) { field=value.coerceIn(0f,1f); invalidateSelf() }
    override fun draw(canvas:Canvas) {
        val b=bounds
        if(b.isEmpty) return
        val d=1f
        val r=when(themeName) { "Glass","Purple Glass" -> 19f*d; "3D" -> 9f*d; "AMOLED" -> 7f*d; else -> 15f*d }
        val rect=RectF(b.left+3f*d,b.top+3f*d,b.right-3f*d,b.bottom-3f*d)
        paint.style=Paint.Style.FILL
        paint.color=when(themeName) {
            "Glass" -> 0x995a7594.toInt()
            "Purple Glass" -> 0x995c347d.toInt()
            "Rainbow RGB" -> 0xff100e22.toInt()
            "Electric Blue" -> 0xff061a2d.toInt()
            "AMOLED" -> Color.BLACK
            "White" -> 0xfff7f9fd.toInt()
            "3D" -> 0xff283344.toInt()
            "Gold" -> 0xff21180b.toInt()
            "Green Matrix" -> 0xff061c12.toInt()
            "Blue Neon" -> 0xff07152b.toInt()
            "Neon" -> 0xff200b35.toInt()
            "Light" -> 0xfff1f4fb.toInt()
            else -> 0xe508080b.toInt()
        }
        if(themeName in listOf("3D","Gold","Electric Blue","Blue Neon","Green Matrix","Purple Glass","Glass","Rainbow RGB","Red Neon","Portrait Fire")) {
            val shades=when(themeName) {
                "Gold" -> intArrayOf(0xff7a5421.toInt(),0xff30200c.toInt(),0xff0d0905.toInt())
                "Electric Blue","Blue Neon" -> intArrayOf(0xff23749b.toInt(),0xff0b2b4a.toInt(),0xff020b1c.toInt())
                "Green Matrix" -> intArrayOf(0xff185e3b.toInt(),0xff0b2b1d.toInt(),0xff020c08.toInt())
                "Purple Glass","Glass" -> intArrayOf(0x995e7ca6.toInt(),0x99513372.toInt(),0x99130c2b.toInt())
                "Rainbow RGB" -> intArrayOf(0xff52416b.toInt(),0xff231b3e.toInt(),0xff090917.toInt())
                "Red Neon","Portrait Fire" -> intArrayOf(0xff70323c.toInt(),0xff2b101b.toInt(),0xff090408.toInt())
                else -> intArrayOf(0xffa7bad3.toInt(),0xff50617d.toInt(),0xff111725.toInt())
            }
            paint.shader=LinearGradient(rect.left,rect.top,rect.left,rect.bottom,
                shades,floatArrayOf(0f,.34f,1f),Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(rect,r,r,paint)
        paint.shader=null
        if(themeName in listOf("3D","Gold","Electric Blue","Blue Neon","Green Matrix","Purple Glass","Glass","Rainbow RGB","Red Neon","Portrait Fire")) {
            paint.color=0xbb02050b.toInt()
            canvas.drawRoundRect(RectF(rect.left+3f,rect.bottom-7f,rect.right-3f,rect.bottom-1f),r/2,r/2,paint)
            paint.color=0x88ffffff
            canvas.drawRoundRect(RectF(rect.left+5f,rect.top+3f,rect.right-5f,rect.top+9f),3f,3f,paint)
        }
        // Glossy top edge and dark lower edge create depth without bitmap effects.
        paint.style=Paint.Style.STROKE
        paint.strokeWidth=1.5f
        paint.color=if(themeName=="Glass" || themeName=="Purple Glass") 0xbbffffff.toInt() else if(light) 0x77ffffff else 0x66ffffff
        canvas.drawArc(RectF(rect.left+3f,rect.top+2f,rect.right-3f,rect.top+rect.height()*.68f),190f,160f,false,paint)
        paint.color=0xaa000000.toInt()
        canvas.drawArc(RectF(rect.left+1f,rect.top+rect.height()*.35f,rect.right-1f,rect.bottom),5f,170f,false,paint)
        val strength=(glow/100f).coerceIn(0f,1f)
        // Translucent strokes simulate a halo without costly blur masks.
        for(i in 3 downTo 1) {
            paint.style=Paint.Style.STROKE
            paint.strokeWidth=(i*1.5f+strength*2f+pulse*3f)*d
            paint.color=if(themeName=="Rainbow RGB") rainbow(phase+i*.13f) else accent
            paint.alpha=((16+strength*24+pulse*28)/i).toInt().coerceIn(0,255)
            canvas.drawRoundRect(rect,r,r,paint)
        }
        paint.strokeWidth=(1.25f+strength*.9f+pulse*1.8f)*d
        paint.color=if(themeName=="Rainbow RGB") rainbow(phase) else accent
        paint.alpha=(205+50*pulse).toInt().coerceIn(0,255)
        canvas.drawRoundRect(rect,r,r,paint)
        if(pulse>0.05f) {
            val x=rect.left+rect.width()*.18f
            val y=rect.top
            val w=min(rect.width()*.36f,27f*d)
            val path=Path().apply {
                moveTo(x,y); lineTo(x+w*.44f,y+rect.height()*.17f)
                lineTo(x+w*.25f,y+rect.height()*.17f)
                lineTo(x+w,y+rect.height()*.43f)
            }
            paint.color=Color.WHITE
            paint.alpha=(220*pulse).toInt().coerceIn(0,255)
            paint.strokeWidth=(1.5f+2f*pulse)*d
            paint.strokeCap=Paint.Cap.ROUND
            canvas.drawPath(path,paint)
        }
        if(animated) {
            val t=phase*2f*PI.toFloat()
            // Three moving ember sparks on the perimeter. No bitmap allocation per frame.
            val perimeter=2f*(rect.width()+rect.height())
            for(i in 0..4) {
                val pos=((phase+i/5f)%1f)*perimeter
                val px:Float; val py:Float
                when {
                    pos<rect.width() -> { px=rect.left+pos;py=rect.top }
                    pos<rect.width()+rect.height() -> { px=rect.right;py=rect.top+pos-rect.width() }
                    pos<2f*rect.width()+rect.height() -> { px=rect.right-(pos-rect.width()-rect.height());py=rect.bottom }
                    else -> { px=rect.left;py=rect.bottom-(pos-2f*rect.width()-rect.height()) }
                }
                val flicker=(0.6f+0.4f*sin(t+i*2.1f)).coerceIn(.1f,1f)
                paint.style=Paint.Style.FILL
                paint.color=if(i==0) Color.WHITE else if(i%2==0) 0xffffb000.toInt() else 0xffff4b0a.toInt()
                paint.alpha=(160*flicker*strength).toInt().coerceIn(0,255)
                canvas.drawCircle(px,py,(1.8f+2.1f*flicker)*d,paint)
            }
            paint.style=Paint.Style.STROKE
            paint.strokeWidth=(1.2f+0.7f*sin(t).coerceAtLeast(0f))*d
            paint.color=if(themeName=="Rainbow RGB") rainbow(phase) else accent
            paint.alpha=(110+75*sin(t).coerceAtLeast(0f)).toInt()
            canvas.drawRoundRect(rect,r,r,paint)
        }
        paint.alpha=255
    }
    private fun rainbow(position:Float):Int {
        val hsv=floatArrayOf(((position%1f+1f)%1f)*360f,0.9f,1f)
        return Color.HSVToColor(hsv)
    }
    override fun setAlpha(alpha:Int) { invalidateSelf() }
    override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) { paint.colorFilter=colorFilter; invalidateSelf() }
    @Deprecated("Deprecated in Java") override fun getOpacity()=PixelFormat.TRANSLUCENT
}
