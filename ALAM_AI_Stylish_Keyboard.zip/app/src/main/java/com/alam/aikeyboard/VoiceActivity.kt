package com.alam.aikeyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Locale

class VoiceActivity : Activity() {
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  val language=intent.getStringExtra("lang") ?: "bn-BD"
  val speech=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
   putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
   putExtra(RecognizerIntent.EXTRA_LANGUAGE,language)
   putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,language)
   putExtra(RecognizerIntent.EXTRA_PROMPT,if(language.startsWith("bn")) "বাংলায় বলুন" else "Speak in English")
  }
  try { startActivityForResult(speech,10) } catch(_:Exception) { Toast.makeText(this,"Speech recognition not installed",Toast.LENGTH_LONG).show(); finish() }
 }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==10 && resultCode==RESULT_OK) {
   val spoken=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
   if(!spoken.isNullOrBlank()) KeyboardService.insertVoiceText(spoken)
  }
  finish()
 }
}
