package com.alam.aikeyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** In-app speech recognition: does not launch an external settings or dictation activity. */
class VoiceActivity : Activity(), RecognitionListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private var language = "bn-BD"
    private var completed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        language = intent.getStringExtra("lang") ?: "bn-BD"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
            setBackgroundColor(Color.rgb(15, 10, 18))
        }
        status = TextView(this).apply {
            text = if (language.startsWith("bn")) "বাংলা ভয়েস টাইপিং" else "English voice typing"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(status)
        val retry = Button(this).apply {
            text = "🎤 Start / Retry"
            setOnClickListener { begin() }
        }
        root.addView(retry)
        val cancel = Button(this).apply { text = "Cancel"; setOnClickListener { finish() } }
        root.addView(cancel)
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        } else begin()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) begin()
            else status.text = "Microphone permission required. Enable it in Android app permissions."
        }
    }

    private fun begin() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition service unavailable on this phone."
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            status.text = if (language.startsWith("bn")) "শুনছি… বাংলায় বলুন" else "Listening… Speak English"
            recognizer?.startListening(request)
        } catch (e: Exception) {
            status.text = "Voice typing could not start: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    override fun onReadyForSpeech(params: Bundle?) { status.text = if (language.startsWith("bn")) "এখন বলুন…" else "Speak now…" }
    override fun onBeginningOfSpeech() { status.text = "Listening…" }
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { status.text = "Processing speech…" }
    override fun onError(error: Int) {
        if (!completed) status.text = when(error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "Speech not recognized. Tap Start / Retry."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Tap Start / Retry."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service network error. Check internet and retry."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission missing."
            else -> "Recognition error ($error). Tap Start / Retry."
        }
    }
    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull { it.isNotBlank() }
        if (text != null) {
            completed = true
            KeyboardService.insertVoiceText(text)
            finish()
        } else status.text = "No words detected. Tap Start / Retry."
    }
    override fun onPartialResults(partialResults: Bundle?) {
        val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!partial.isNullOrBlank()) status.text = partial
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}
    override fun onDestroy() { recognizer?.cancel(); recognizer?.destroy(); recognizer = null; super.onDestroy() }
}
