package com.alam.aikeyboard

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast

/** Permission gate only. Dictation runs inside the IME, preserving editor focus. */
class VoiceActivity : Activity() {
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) returnToKeyboard(true)
  else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),77)
 }
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
  super.onRequestPermissionsResult(requestCode,permissions,grantResults)
  if(requestCode==77) returnToKeyboard(grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED)
 }
 private fun returnToKeyboard(granted:Boolean) {
  if(granted) KeyboardService.requestVoiceStartAfterPermission()
  else Toast.makeText(this,"Microphone permission required",Toast.LENGTH_LONG).show()
  finish()
 }
}
