package com.alam.aikeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.net.Uri
import android.content.Context

class MainActivity : Activity() {
 private lateinit var root: LinearLayout
 private val prefs by lazy { getSharedPreferences("keyboard", Context.MODE_PRIVATE) }
 private fun label(s:String) = TextView(this).apply { text=s; textSize=17f; setTextColor(Color.rgb(35,35,48)); setPadding(12,14,12,14) }
 private fun button(s:String, click:()->Unit) { root.addView(Button(this).apply { text=s; setOnClickListener { click() } }) }
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); render() }
 private fun render() {
  root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,22,22,22) }
  val scroll=ScrollView(this).apply { addView(root) }; setContentView(scroll)
  root.addView(label("ALAM AI Stylish Keyboard • v4.5 Free"))
  root.addView(label("Enable the keyboard, then select it as your input method. Numeric fields switch to a number pad when the app identifies them correctly."))
  button("1. Enable keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
  button("2. Select keyboard") { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showInputMethodPicker() }
  root.addView(label("All themes are free. Tap the globe key to switch English → Banglish → বাংলা. Banglish converts romanized words into Bengali as you type; press space to confirm. Common phrases have a built-in dictionary, and uncommon words use approximate phonetic conversion."))
  root.addView(label("Default: Portrait Fire (your photo + red glow). All themes are unlocked."))
  root.addView(label("Theme gallery — previews show each theme’s actual key colors and shape. Tap to apply; reopen the keyboard to refresh."))
  val palette=listOf(
   Triple("Portrait Fire",0xff240005.toInt(),0xffff2735.toInt()),
   Triple("Red Neon",0xff100307.toInt(),0xfff22735.toInt()),
   Triple("Rainbow RGB",0xff100a26.toInt(),0xffff47bf.toInt()),
   Triple("Electric Blue",0xff03152b.toInt(),0xff00dcff.toInt()),
   Triple("Purple Glass",0xff41235b.toInt(),0xffe49cff.toInt()),
   Triple("AMOLED",Color.BLACK,0xffa4b4c9.toInt()),
   Triple("White",0xfff4f6fa.toInt(),0xff8796ac.toInt()),
   Triple("Blue Neon",0xff03142b.toInt(),0xff16baff.toInt()),
   Triple("Neon",0xff240b44.toInt(),0xffc45bff.toInt()),
   Triple("Gold",0xff2c210a.toInt(),0xffffc84c.toInt()),
   Triple("Green Matrix",0xff041e12.toInt(),0xff39ed87.toInt()),
   Triple("Glass",0xff546e8a.toInt(),0xffd4e8ff.toInt()),
   Triple("3D",0xff1b2637.toInt(),0xff8796ac.toInt()),
   Triple("Dark",0xff141821.toInt(),0xff737f94.toInt()),
   Triple("Light",0xffe4eaf1.toInt(),0xff788ca9.toInt())
  )
  palette.chunked(2).forEach { pair ->
   val previewRow=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   pair.forEach { (title,base,accent) ->
    val preview=TextView(this).apply {
     text="${title}\n  A     B     C  \n  1     2     3  "
     gravity=Gravity.CENTER
     textSize=16f
     setTextColor(if(title=="Light" || title=="White") Color.BLACK else Color.WHITE)
     setPadding(8,18,8,18)
     background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(base,base)).apply {
      cornerRadius=if(title=="Glass") 28f else if(title=="3D") 9f else 18f
      setStroke(4,accent)
     }
     setOnClickListener {
      prefs.edit().putString("theme",title).apply()
      Toast.makeText(this@MainActivity,"$title applied — reopen keyboard",Toast.LENGTH_SHORT).show()
     }
    }
    previewRow.addView(preview,LinearLayout.LayoutParams(0,155,1f).apply { setMargins(4,4,4,4) })
   }
   root.addView(previewRow)
  }
  root.addView(label("Keyboard theme"))
  val themes=listOf("Portrait Fire","Red Neon","Rainbow RGB","Electric Blue","Purple Glass","Dark","Light","Neon","Blue Neon","Gold","Green Matrix","Glass","3D","AMOLED","White","Photo")
  val spinner=Spinner(this); spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,themes)
  spinner.setSelection(themes.indexOf(prefs.getString("theme","Portrait Fire"))); root.addView(spinner)
  button("Save theme") { prefs.edit().putString("theme",spinner.selectedItem.toString()).apply(); Toast.makeText(this,"Theme saved",Toast.LENGTH_SHORT).show() }
  button("Choose keyboard background photo") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) },22) }
  root.addView(label("GENERAL SETTINGS"))
  option("Auto-capitalization", "auto_capitalization", true)
  option("Auto-correction (basic offline suggestions)", "auto_correction", false)
  option("Show correction suggestions", "suggestion_row", true)
  option("Vibrate on keypress", "vibrate", false)
  option("Sound on keypress", "key_sound", false)
  option("Key popup on keypress", "key_popup", true)
  option("Number row", "number_row", true)
  option("Selector row", "selector_row", false)
  root.addView(label("EMOJI"))
  option("Emoji prediction (basic)", "emoji_prediction", false)
  option("Emoji key", "emoji_key", true)
  root.addView(label("TEXT CORRECTION"))
  option("Block offensive words in suggestions", "block_offensive", true)
  option("Next-word suggestions", "next_word", true)
  option("Double-space period", "double_space_period", true)
  root.addView(label("GESTURE AND TOUCH"))
  root.addView(label("Swipe-to-type is not implemented yet; this setting is not shown as a working feature."))
  slider("Key long press delay (ms)", "long_press_delay",300,150,700)
  slider("Keypress vibration duration (ms)", "vibration_duration",26,5,80)
  root.addView(label("ADVANCED & PRIVACY"))
  option("Low RAM mode", "low_ram", false)
  option("Show compact tools row", "compact_tools", true)
  button("Clear personal suggestion words") { prefs.edit().remove("custom_words").apply(); Toast.makeText(this,"Personal words cleared",Toast.LENGTH_SHORT).show(); render() }
  root.addView(label("Contacts suggestions, cloud stickers and full gesture typing require separate implementation. Typed text is not shared for analytics."))
  root.addView(label("Keyboard appearance and performance"))
  root.addView(label("New: keypress spring-back animation and expanded emoji picker. Animations automatically stay off in secure fields and Low RAM mode."))
  root.addView(label("New: hold Delete to erase continuously. Hold the Spacebar to move the cursor left or right."))
  root.addView(label("Portrait Fire photo visibility"))
  slider("Portrait background darkness (%)", "portrait_dim",25,0,85)
  root.addView(label("Change these settings, then reopen the keyboard to see the new theme."))
  root.addView(CheckBox(this).apply { text="Show suggestion shortcuts"; isChecked=prefs.getBoolean("suggestion_row",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("suggestion_row",v).apply() } })
  root.addView(CheckBox(this).apply { text="Show number row"; isChecked=prefs.getBoolean("number_row",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("number_row",v).apply() } })
  root.addView(CheckBox(this).apply { text="Show ALAM AI header"; isChecked=prefs.getBoolean("show_brand",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("show_brand",v).apply() } })
  root.addView(CheckBox(this).apply { text="Double space inserts full stop"; isChecked=prefs.getBoolean("double_space_period",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("double_space_period",v).apply() } })
  root.addView(CheckBox(this).apply { text="Keypress sound"; isChecked=prefs.getBoolean("key_sound",false); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("key_sound",v).apply() } })
  slider("Key height", "height",58,44,76)
  slider("Font size", "font",18,14,26)
  root.addView(CheckBox(this).apply { text="Fire & lightning on key press"; isChecked=prefs.getBoolean("fire_lightning",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("fire_lightning",v).apply() } })
  root.addView(CheckBox(this).apply { text="Moving fire sparks and running glow"; isChecked=prefs.getBoolean("ambient_fire",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("ambient_fire",v).apply() } })
  slider("Fire animation duration (ms)", "animation_speed",1800,700,4000)
  root.addView(CheckBox(this).apply { text="Low RAM mode (disable animations)"; isChecked=prefs.getBoolean("low_ram",false); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("low_ram",v).apply() } })
  slider("Neon glow strength", "glow",70,0,100)
  root.addView(CheckBox(this).apply { text="Vibrate on keypress"; isChecked=prefs.getBoolean("vibrate",false); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("vibrate",v).apply() } })
  root.addView(label("Voice typing language"))
  val voiceOptions=listOf("Auto","বাংলা","English")
  val voiceSpinner=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,voiceOptions) }
  voiceSpinner.setSelection(voiceOptions.indexOf(prefs.getString("voice_language","Auto")).coerceAtLeast(0))
  root.addView(voiceSpinner)
  button("Save voice language") { prefs.edit().putString("voice_language",voiceSpinner.selectedItem.toString()).apply(); Toast.makeText(this,"Voice language saved",Toast.LENGTH_SHORT).show() }
  root.addView(label("Personal suggestion words (one word per line). Only words you save here are stored."))
  val customWords=EditText(this).apply { hint="hello\nassalamualaikum"; minLines=3; setSingleLine(false); setText(prefs.getString("custom_words","")) }
  root.addView(customWords)
  button("Save custom suggestions") { prefs.edit().putString("custom_words",customWords.text.toString().lines().map { it.trim() }.filter { it.isNotBlank() }.distinct().take(100).joinToString("\n")).apply(); Toast.makeText(this,"Suggestions saved",Toast.LENGTH_SHORT).show() }
  root.addView(label("AI button currently offers offline text formatting and quick replies, not cloud-generated AI. No typed content is uploaded."))
  root.addView(label("Voice typing: microphone button uses Android speech recognition. Bengali and English recognition depend on your device's installed speech services and may require internet."))
  root.addView(label("Photo opacity"))
  val opacity=SeekBar(this).apply { max=100; progress=prefs.getInt("opacity",35) }; root.addView(opacity)
  opacity.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean) { prefs.edit().putInt("opacity",p).apply() }; override fun onStartTrackingTouch(s:SeekBar?) {}; override fun onStopTrackingTouch(s:SeekBar?) {} })
  root.addView(label("Favorite recipient numbers (never save banking PINs here)"))
  val name=EditText(this).apply { hint="Label e.g. Home" }; root.addView(name)
  val number=EditText(this).apply { hint="Phone number"; inputType=android.text.InputType.TYPE_CLASS_PHONE }; root.addView(number)
  button("Save favorite number") { val n=number.text.toString().trim(); if(n.matches(Regex("[+0-9]{5,20}"))) { val title=name.text.toString().replace("|", " ").replace(";", " ").take(30); val current=prefs.getString("favorites","") ?: ""; prefs.edit().putString("favorites",(current+";"+title+"|"+n).trim(';')).apply(); render() } else Toast.makeText(this,"Enter a valid number",Toast.LENGTH_SHORT).show() }
  val favs=prefs.getString("favorites","") ?: ""
  if(favs.isNotBlank()) { root.addView(label("Saved favorites (tap to delete)")); favs.split(';').forEach { entry -> button(entry.replace('|',' ')) { prefs.edit().putString("favorites",favs.split(';').filter { it!=entry }.joinToString(";")).apply(); render() } } }
  root.addView(label("Privacy: favorites are stored locally in app preferences. This app does not request Internet permission and does not collect typed text. Banglish typing is included offline. Cloud AI, GIF search and stickers are not implemented yet; they require additional integrations. No premium subscription or paid unlock is present."))
 }
 private fun option(title:String,key:String,default:Boolean) {
  root.addView(CheckBox(this).apply {
   text=title
   textSize=16f
   isChecked=prefs.getBoolean(key,default)
   setPadding(10,12,10,12)
   setOnCheckedChangeListener { _,checked -> prefs.edit().putBoolean(key,checked).apply() }
  })
 }
 private fun slider(title:String,key:String,default:Int,min:Int,max:Int) {
  val caption=label("$title: ${prefs.getInt(key,default)}")
  root.addView(caption)
  root.addView(SeekBar(this).apply { this.max=max-min; progress=prefs.getInt(key,default).coerceIn(min,max)-min
   setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
    override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean) { if(fromUser) { prefs.edit().putInt(key,p+min).apply(); caption.text="$title: ${p+min}" } }
    override fun onStartTrackingTouch(s:SeekBar?) {}
    override fun onStopTrackingTouch(s:SeekBar?) {}
   })
  })
 }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==22 && resultCode==RESULT_OK) { data?.data?.let { uri -> try { contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch(_:Exception) {} ; prefs.edit().putString("photo",uri.toString()).putString("theme","Photo").apply(); render() } } }
}
