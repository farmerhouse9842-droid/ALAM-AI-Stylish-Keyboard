package com.alam.aikeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.net.Uri
import android.content.Context

class MainActivity : Activity() {
 private lateinit var root: LinearLayout
 private val prefs by lazy { getSharedPreferences("keyboard", Context.MODE_PRIVATE) }
 private fun label(s:String) = TextView(this).apply { text=s; textSize=17f; setTextColor(Color.rgb(35,35,48)); setPadding(12,14,12,14) }
 private fun button(s:String, click:()->Unit) { root.addView(Button(this).apply { text=s; setOnClickListener { click() } }) }
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); render() }
 private fun render() {
  root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,22,22,22) }
  val scroll=ScrollView(this).apply { addView(root) }; setContentView(scroll)
  root.addView(label("ALAM AI Stylish Keyboard • v1.4 Free"))
  root.addView(label("Enable the keyboard, then select it as your input method. Numeric fields switch to a number pad when the app identifies them correctly."))
  button("1. Enable keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
  button("2. Select keyboard") { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showInputMethodPicker() }
  root.addView(label("All themes are free. Tap the globe key to switch English → Banglish → বাংলা. Banglish converts romanized words into Bengali as you type; press space to confirm. Common phrases have a built-in dictionary, and uncommon words use approximate phonetic conversion."))
  root.addView(label("Default: Portrait Fire (your photo + red glow). All themes are unlocked."))
  root.addView(label("Keyboard theme"))
  val themes=listOf("Portrait Fire","Red Neon","Dark","Light","Neon","Blue Neon","Gold","Green Matrix","Glass","3D","Photo")
  val spinner=Spinner(this); spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,themes)
  spinner.setSelection(themes.indexOf(prefs.getString("theme","Portrait Fire"))); root.addView(spinner)
  button("Save theme") { prefs.edit().putString("theme",spinner.selectedItem.toString()).apply(); Toast.makeText(this,"Theme saved",Toast.LENGTH_SHORT).show() }
  button("Choose keyboard background photo") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) },22) }
  root.addView(label("Keyboard appearance and performance"))
  slider("Key height", "height",52,40,72)
  slider("Font size", "font",18,14,26)
  root.addView(CheckBox(this).apply { text="Fire & lightning on key press"; isChecked=prefs.getBoolean("fire_lightning",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("fire_lightning",v).apply() } })
  root.addView(CheckBox(this).apply { text="Moving fire sparks and running glow"; isChecked=prefs.getBoolean("ambient_fire",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("ambient_fire",v).apply() } })
  slider("Fire animation duration (ms)", "animation_speed",1800,700,4000)
  root.addView(CheckBox(this).apply { text="Low RAM mode (disable animations)"; isChecked=prefs.getBoolean("low_ram",false); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("low_ram",v).apply() } })
  slider("Neon glow strength", "glow",70,0,100)
  root.addView(CheckBox(this).apply { text="Vibrate on keypress"; isChecked=prefs.getBoolean("vibrate",false); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("vibrate",v).apply() } })
  root.addView(label("Voice typing: microphone button uses Android speech recognition. Bengali and English recognition depend on your device's installed speech services and may require internet."))
  root.addView(label("Photo opacity"))
  val opacity=SeekBar(this).apply { max=100; progress=prefs.getInt("opacity",35) }; root.addView(opacity)
  opacity.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean) { prefs.edit().putInt("opacity",p).apply() }; override fun onStartTrackingTouch(s:SeekBar?) {}; override fun onStopTrackingTouch(s:SeekBar?) {} })
  root.addView(label("Favorite recipient numbers (never save banking PINs here)"))
  val name=EditText(this).apply { hint="Label e.g. Home" }; root.addView(name)
  val number=EditText(this).apply { hint="Phone number"; inputType=android.text.InputType.TYPE_CLASS_PHONE }; root.addView(number)
  button("Save favorite number") { val n=number.text.toString().trim(); if(n.matches(Regex("[+0-9]{5,20}"))) { val title=name.text.toString().replace("|", " ").replace(";", " ").take(30); val current=prefs.getString("favorites","") ?: ""; prefs.edit().putString("favorites",(current+";"+title+"|"+n).trim(';')).apply(); render() } else Toast.makeText(this,"Enter a valid number",Toast.LENGTH_SHORT).show() }
  val favs=prefs.getString("favorites","") ?: ""
  if(favs.isNotBlank()) { root.addView(label("Saved favorites (tap to delete)")); favs.split(';').forEach { entry -> button(entry.replace('|',' ')) { prefs.edit().putString("favorites",favs.split(';').filter { it!=entry }.joinToString(";")).apply(); render() } } }
  root.addView(label("Privacy: favorites are stored locally in app preferences. This app does not request Internet permission and does not collect typed text. Banglish typing is included offline. Cloud AI, GIF search and stickers are not implemented yet; they require additional integrations. No premium subscription or paid unlock is present."))
 }
 private fun slider(title:String,key:String,default:Int,min:Int,max:Int) {
  val caption=label("$title: ${prefs.getInt(key,default)}")
  root.addView(caption)
  root.addView(SeekBar(this).apply { this.max=max-min; progress=prefs.getInt(key,default).coerceIn(min,max)-min
   setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
    override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean) { if(fromUser) { prefs.edit().putInt(key,p+min).apply(); caption.text="$title: ${p+min}" } }
    override fun onStartTrackingTouch(s:SeekBar?) {}
    override fun onStopTrackingTouch(s:SeekBar?) {}
   })
  })
 }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==22 && resultCode==RESULT_OK) { data?.data?.let { uri -> try { contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch(_:Exception) {} ; prefs.edit().putString("photo",uri.toString()).putString("theme","Photo").apply(); render() } } }
}
