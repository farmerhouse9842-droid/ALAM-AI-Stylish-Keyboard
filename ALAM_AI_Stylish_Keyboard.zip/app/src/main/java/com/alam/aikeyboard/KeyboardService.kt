package com.alam.aikeyboard

import android.inputmethodservice.InputMethodService
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.graphics.drawable.ColorDrawable
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.content.Intent
import android.view.HapticFeedbackConstants
import java.lang.ref.WeakReference

class KeyboardService : InputMethodService() {
 companion object {
  private var active:WeakReference<KeyboardService>?=null
  fun insertVoiceText(text:String) { active?.get()?.commit(text) }
 }
 override fun onCreate() { super.onCreate(); active=WeakReference(this) }
 override fun onDestroy() { stopAmbient(); active?.clear(); super.onDestroy() }

 private val animatedKeys=mutableListOf<NeonKeyDrawable>()
 private var ambientAnimator:ValueAnimator?=null
 private fun stopAmbient() { ambientAnimator?.cancel(); ambientAnimator=null; animatedKeys.clear() }
 private fun startAmbient() {
  if(prefs.getBoolean("low_ram",false) || !prefs.getBoolean("ambient_fire",true)) return
  if(animatedKeys.isEmpty()) return
  ambientAnimator=ValueAnimator.ofFloat(0f,1f).apply {
   duration=prefs.getInt("animation_speed",1800).toLong().coerceIn(700L,4000L)
   repeatCount=ValueAnimator.INFINITE
   addUpdateListener { a -> val phase=a.animatedValue as Float; animatedKeys.forEachIndexed { index,d -> d.phase=(phase+index*.037f)%1f } }
   start()
  }
 }
 override fun onFinishInputView(finishingInput:Boolean) { stopAmbient(); super.onFinishInputView(finishingInput) }
 private var secureField=false
 private var numeric=false
 private var shift=false
 private var bangla=false
 private var symbols=false
 private var banglish=false
 private var pending=""
 private var capsLocked=false
 private lateinit var board:LinearLayout
 private val prefs by lazy { getSharedPreferences("keyboard",Context.MODE_PRIVATE) }
 override fun onCreateInputView():View { board=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; build(); return board }
 override fun onStartInputView(info:EditorInfo?,restarting:Boolean) { super.onStartInputView(info,restarting); val type=(info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS; numeric=type==InputType.TYPE_CLASS_NUMBER || type==InputType.TYPE_CLASS_PHONE || type==InputType.TYPE_CLASS_DATETIME; secureField=((info?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION) in listOf(InputType.TYPE_TEXT_VARIATION_PASSWORD,InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,InputType.TYPE_NUMBER_VARIATION_PASSWORD); symbols=false; shift=false; pending=""; if(::board.isInitialized) build() }
 private fun background():Drawable {
  if(prefs.getString("theme","Portrait Fire")=="Portrait Fire") { val picture=resources.getDrawable(com.alam.aikeyboard.R.drawable.alam_portrait_bg,theme); return LayerDrawable(arrayOf(picture,ColorDrawable(0x66000000))) } val theme=prefs.getString("theme","Portrait Fire"); val colors=when(theme) { "Light"->intArrayOf(0xffe8edf4.toInt(),0xffcbd5e1.toInt()); "Neon"->intArrayOf(0xff230b52.toInt(),0xff7c1c90.toInt()); "Glass"->intArrayOf(0xff7c95b3.toInt(),0xffb7d3e6.toInt()); "3D"->intArrayOf(0xff394150.toInt(),0xff141b2b.toInt()); "Portrait Fire"->intArrayOf(0xff080305.toInt(),0xff220008.toInt()); "Red Neon"->intArrayOf(0xff090909.toInt(),0xff160005.toInt()); "Blue Neon"->intArrayOf(0xff03132d.toInt(),0xff020713.toInt()); "Gold"->intArrayOf(0xff28200c.toInt(),0xff080808.toInt()); "Green Matrix"->intArrayOf(0xff02170a.toInt(),0xff030603.toInt()); else->intArrayOf(0xff252b39.toInt(),0xff111827.toInt()) }; if(theme=="Photo") { try { val uri=android.net.Uri.parse(prefs.getString("photo", "")); val stream=contentResolver.openInputStream(uri); val bmp=BitmapFactory.decodeStream(stream); stream?.close(); if(bmp!=null) return BitmapDrawable(resources,bmp).apply { alpha=(prefs.getInt("opacity",35)*255/100).coerceIn(0,255); gravity=android.view.Gravity.FILL } } catch(_:Exception) {} }; return GradientDrawable(GradientDrawable.Orientation.TL_BR,colors) }
 private fun key(text:String,weight:Float=1f, action:()->Unit):Button {
  val theme=prefs.getString("theme","Portrait Fire")
  val accent=when(theme) { "Blue Neon"->0xff00bbff.toInt(); "Gold"->0xffffc247.toInt(); "Green Matrix"->0xff00df68.toInt(); "Neon"->0xffca4bff.toInt(); "Portrait Fire"->0xffff2028.toInt(); else->0xffe00024.toInt() }
  val glow=prefs.getInt("glow",70)
  val height=prefs.getInt("height",52).coerceIn(40,72)
  return Button(this).apply {
   this.text=text; textSize=prefs.getInt("font",18).toFloat(); isAllCaps=false
   setTextColor(if(theme=="Light") Color.BLACK else Color.WHITE)
   val neon=NeonKeyDrawable(accent,theme=="Light",glow)
   background=neon
   if(!prefs.getBoolean("low_ram",false) && prefs.getBoolean("ambient_fire",true)) { neon.animated=true; animatedKeys.add(neon) }
   elevation=(glow/14f).coerceAtMost(9f)
   stateListAnimator=null
   setOnClickListener {
    if(prefs.getBoolean("vibrate",false)) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    if(prefs.getBoolean("fire_lightning",true) && glow>0 && !prefs.getBoolean("low_ram",false)) {
     ValueAnimator.ofFloat(1f,0f).apply {
      duration=190L; interpolator=DecelerateInterpolator()
      addUpdateListener { neon.pulse=it.animatedValue as Float }
      start()
     }
    }
    action()
   }
   layoutParams=LinearLayout.LayoutParams(0,height.dp,weight).apply { setMargins(2.dp,3.dp,2.dp,3.dp) }
   minWidth=0; minHeight=0; setPadding(0,0,0,0)
  }
 }
 private val Int.dp:Int get()=(this*resources.displayMetrics.density).toInt()
 private fun row(keys:List<String>,action:(String)->Unit) { val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }; keys.forEach { k -> r.addView(key(k) { action(k) }) }; board.addView(r) }
 private fun commit(s:String) { currentInputConnection?.commitText(s,1) }
 private fun flushBanglish() { if(pending.isNotEmpty()) { currentInputConnection?.commitText(Banglish.convert(pending),1); pending="" } }
 private fun typeLetter(s:String) { if(banglish && !symbols && !numeric) { pending+=s.lowercase(); currentInputConnection?.setComposingText(Banglish.convert(pending),1) } else commit(s) }
 private fun erase() { if(banglish && pending.isNotEmpty()) { pending=pending.dropLast(1); if(pending.isEmpty()) currentInputConnection?.finishComposingText() else currentInputConnection?.setComposingText(Banglish.convert(pending),1) } else currentInputConnection?.deleteSurroundingText(1,0) }
 private fun switchLanguage() { flushBanglish(); when { banglish -> { banglish=false; bangla=true }; bangla -> { bangla=false; banglish=false }; else -> { banglish=true; bangla=false } }; build() }
 private fun build() {
  stopAmbient(); board.removeAllViews(); board.background=background(); board.setPadding(4.dp,6.dp,4.dp,8.dp)
  val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  top.addView(key(if(numeric) "123" else if(banglish) "Banglish" else if(bangla) "বাংলা" else "EN") { if(!numeric) { switchLanguage() } })
  if(!secureField) {
   top.addView(key("🎨") { openSettings() })
   top.addView(key("✦") { showAiTools() })
   top.addView(key("▤") { showClipboard() })
   top.addView(key("★") { showFavorites() })
   top.addView(key("🎙") { launchVoice() })
   top.addView(key("Aa") { showFonts() })
   top.addView(key("☻") { showEmoji() })
  }
  top.addView(key("⚙") { openSettings() })
  board.addView(top)
  if(numeric) { listOf(listOf("1","2","3"),listOf("4","5","6"),listOf("7","8","9"),listOf("*","0","#"),listOf("-",".","⌫")).forEach { row(it) { k -> when(k) { "⌫"->erase(); else->commit(k) } } }; startAmbient(); return }
  val rows=if(symbols) listOf("1234567890","@#₹৳%&*()-","/;:!?.,") else if(bangla) listOf("ৌৈাীূবহগদজড","োে্িুপ রকতচট".replace(" ",""),"ংম নলসযষশড়".replace(" ","")) else listOf("qwertyuiop","asdfghjkl","zxcvbnm")
  rows.forEach { chars -> row(chars.map { it.toString() }) { k -> typeLetter(if(shift) k.uppercase() else k) } }
  val bottom=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  bottom.addView(key("⇧") { shift=!shift; build() }); bottom.addView(key("?123") { flushBanglish(); symbols=!symbols; build() }); bottom.addView(key("🌐") { symbols=false; switchLanguage() }); bottom.addView(key("space",3f) { flushBanglish(); commit(" ") }); bottom.addView(key("⌫") { erase() }); bottom.addView(key("↵") { flushBanglish(); if(currentInputConnection?.performEditorAction(EditorInfo.IME_ACTION_DONE)!=true) commit("\n") }); board.addView(bottom)
  startAmbient()
 }
 private fun openSettings() { startActivity(Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
 private fun showClipboard() { if(secureField) return; val clipboard=getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; val clip=clipboard.primaryClip; val value=if(clip!=null && clip.itemCount>0) clip.getItemAt(0).coerceToText(this).toString() else ""; if(value.isNotBlank()) commit(value) else Toast.makeText(this,"Clipboard empty",Toast.LENGTH_SHORT).show() }
 private fun showAiTools() { if(secureField) return; val popup=PopupMenu(this,board.getChildAt(0)); listOf("Quick reply: Thank you!","Quick reply: ধন্যবাদ!","Quick reply: ঠিক আছে","Insert greeting: আসসালামু আলাইকুম").forEachIndexed { i,v -> popup.menu.add(0,i,i,v) }; popup.setOnMenuItemClickListener { commit(it.title.toString().substringAfter(": ")); true }; popup.show() }
 private fun launchVoice() {
  if(secureField) return
  val i=Intent(this,VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  i.putExtra("lang",if(bangla||banglish) "bn-BD" else "en-US")
  try { startActivity(i) } catch(_:Exception) { Toast.makeText(this,"Voice typing unavailable",Toast.LENGTH_SHORT).show() }
 }
 private fun showFonts() {
  if(secureField) return
  val choices=arrayOf("𝐁𝐨𝐥𝐝","𝘐𝘵𝘢𝘭𝘪𝘤","𝓢𝓬𝓻𝓲𝓹𝓽","𝔊𝔬𝔱𝔥𝔦𝔠")
  val popup=PopupMenu(this,board.getChildAt(0)); choices.forEachIndexed { i,v -> popup.menu.add(0,i,i,v) }
  popup.setOnMenuItemClickListener { val text=currentInputConnection?.getSelectedText(0)?.toString().orEmpty(); if(text.isEmpty()) { Toast.makeText(this,"Select English text first",Toast.LENGTH_SHORT).show() } else { val base=if(it.itemId==0) 0x1D400 else if(it.itemId==1) 0x1D434 else if(it.itemId==2) 0x1D468 else 0x1D504; val converted=buildString { text.forEach { c -> val offset=when { c in 'A'..'Z' -> c-'A'; c in 'a'..'z' -> c-'a'+26; else -> -1 }; if(offset<0) append(c) else appendCodePoint(base+offset) } }; commit(converted) }; true }; popup.show()
 }
 private fun showEmoji() {
  if(secureField) return
  val popup=PopupMenu(this,board.getChildAt(0))
  listOf("😀","❤️","😂","😍","👍","🔥","✨","🙏").forEachIndexed { i,v -> popup.menu.add(0,i,i,v) }
  popup.setOnMenuItemClickListener { commit(it.title.toString()); true }; popup.show()
 }
 private fun showFavorites() { if(secureField) return; val items=(prefs.getString("favorites","") ?: "").split(';').filter { it.contains('|') }; if(items.isEmpty()) { Toast.makeText(this,"Add favorite numbers in keyboard settings",Toast.LENGTH_SHORT).show(); return }; val popup=PopupMenu(this,board.getChildAt(0)); items.forEachIndexed { i,item -> popup.menu.add(0,i,i,item.replace('|',' ')) }; popup.setOnMenuItemClickListener { item -> items.getOrNull(item.itemId)?.substringAfter('|')?.let { commit(it) }; true }; popup.show() }
}
