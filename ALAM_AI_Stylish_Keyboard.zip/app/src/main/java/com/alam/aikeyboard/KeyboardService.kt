package com.alam.aikeyboard

import android.inputmethodservice.InputMethodService
import android.Manifest
import android.content.pm.PackageManager
import android.speech.SpeechRecognizer
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.graphics.drawable.ColorDrawable
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.text.InputType
import android.view.View
import android.view.MotionEvent
import android.view.Gravity
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.content.Intent
import android.view.HapticFeedbackConstants
import android.media.AudioManager
import java.lang.ref.WeakReference

class KeyboardService : InputMethodService() {
 companion object {
  private var active:WeakReference<KeyboardService>?=null
  fun requestVoiceStartAfterPermission() { active?.get()?.startVoiceAfterPermission() }
  fun insertVoiceText(text:String) {
   val service=active?.get() ?: return
   service.getSharedPreferences("voice_delivery",Context.MODE_PRIVATE).edit().putString("pending",text).apply()
   service.deliverPendingVoice()
  }
 }
 private val clipManager by lazy { getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager }
 private val clipboardListener=ClipboardManager.OnPrimaryClipChangedListener { saveCurrentClipboard() }
 override fun onCreate() { super.onCreate(); active=WeakReference(this); clipManager.addPrimaryClipChangedListener(clipboardListener) }

 override fun onDestroy() { clipManager.removePrimaryClipChangedListener(clipboardListener); stopVoice(); dismissKeyPreview(); stopRepeatDelete(); stopAmbient(); active?.clear(); super.onDestroy() }

 private val animatedKeys=mutableListOf<NeonKeyDrawable>()
 private var keyPreview:PopupWindow?=null
 private val previewHandler=Handler(Looper.getMainLooper())
 private val closePreview=Runnable { dismissKeyPreview() }
 private fun dismissKeyPreview() {
  previewHandler.removeCallbacks(closePreview)
  try { keyPreview?.dismiss() } catch (_:Exception) {}
  keyPreview=null
 }
 private fun showKeyPreview(button:Button, label:String) {
  if(secureField || !prefs.getBoolean("key_popup",true) || label.isBlank() || label.length>3) return
  dismissKeyPreview()
  val accent=when(prefs.getString("theme","Portrait Fire")) {
   "Electric Blue","Blue Neon"->0xff00cfff.toInt()
   "Purple Glass","Neon"->0xffdf83ff.toInt()
   "Gold"->0xffffc247.toInt()
   "Green Matrix"->0xff30f38a.toInt()
   else->0xffff293b.toInt()
  }
  val preview=TextView(this).apply {
   text=label; gravity=Gravity.CENTER; textSize=30f
   setTextColor(Color.WHITE)
   background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
    intArrayOf(0xff404050.toInt(),0xff08080e.toInt())).apply {
    cornerRadius=13.dp.toFloat(); setStroke(2.dp,accent)
   }
   elevation=9.dp.toFloat()
  }
  val width=58.dp; val height=67.dp
  val popup=PopupWindow(preview,width,height,false).apply {
   isTouchable=false; isFocusable=false; isOutsideTouchable=false
   setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
   inputMethodMode=PopupWindow.INPUT_METHOD_NOT_NEEDED
  }
  // Anchor to the key in IME window coordinates, not absolute screen coordinates.
  // A negative dropdown offset places the entire preview ABOVE the pressed key.
  popup.isClippingEnabled=false
  val xOffset=(button.width-width)/2
  val yOffset=-(button.height+height+4.dp)
  try { popup.showAsDropDown(button,xOffset,yOffset,Gravity.START); keyPreview=popup }
  catch (_:Exception) { popup.dismiss() }
 }

 private val repeatHandler=Handler(Looper.getMainLooper())
 private var repeatDelete:Runnable?=null
 private fun stopRepeatDelete() { repeatDelete?.let { repeatHandler.removeCallbacks(it) }; repeatDelete=null }
 private fun deleteKey():Button = key("⌫") { /* Touch handler below owns deletion. */ }.apply {
  // Start deleting immediately; accelerate while held and stop as soon as released.
  setOnTouchListener { _, event ->
   when(event.actionMasked) {
    MotionEvent.ACTION_DOWN -> {
     dismissKeyPreview(); stopRepeatDelete(); erase()
     val task=object:Runnable {
      private var count=0
      override fun run() {
       erase(); count++
       repeatHandler.postDelayed(this, if(count<10) 48L else 28L)
      }
     }
     repeatDelete=task
     repeatHandler.postDelayed(task,230L)
     true
    }
    MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL -> {
     stopRepeatDelete(); true
    }
    else -> true
   }
  }
 }
 private var ambientAnimator:ValueAnimator?=null
 private fun stopAmbient() { ambientAnimator?.cancel(); ambientAnimator=null; animatedKeys.clear() }
 private fun startAmbient() {
  if(secureField || prefs.getBoolean("low_ram",false) || !prefs.getBoolean("ambient_fire",true)) return
  if(animatedKeys.isEmpty()) return
  ambientAnimator=ValueAnimator.ofFloat(0f,1f).apply {
   duration=prefs.getInt("animation_speed",1800).toLong().coerceIn(700L,4000L)
   repeatCount=ValueAnimator.INFINITE
   addUpdateListener { a -> val phase=a.animatedValue as Float; animatedKeys.forEachIndexed { index,d -> d.phase=(phase+index*.037f)%1f } }
   start()
  }
 }
 override fun onFinishInputView(finishingInput:Boolean) { dismissKeyPreview(); stopRepeatDelete(); stopAmbient(); pending=""; composingActive=false; lastTyped=""; super.onFinishInputView(finishingInput) }
 private var secureField=false
 private var composingActive=false
 private var numeric=false
 private var shift=false
 private var bangla=false
 private var symbols=false
 private var extraSymbols=false
 private var banglish=false
 private var pending=""
 private var capsLocked=false
 private var lastShiftTap=0L
 private var lastFieldSignature=""
 private var lastSpaceAt=0L
 private var lastTyped=""
 private var lastCommittedSpace=false

 private var suggestionStrip:LinearLayout?=null
 private var toolsExpanded=false
 private var emojiPage=false
 private lateinit var board:LinearLayout
 private val prefs by lazy { getSharedPreferences("keyboard",Context.MODE_PRIVATE) }
 private val voiceHandler=Handler(Looper.getMainLooper())
 private fun deliverPendingVoice() {
  val store=getSharedPreferences("voice_delivery",Context.MODE_PRIVATE)
  val pending=store.getString("pending",null) ?: return
  if(pending.isBlank()) { store.edit().remove("pending").apply(); return }
  if(secureField) return
  val connection=currentInputConnection ?: return
  try {
   if(connection.commitText(pending,1)) {
    store.edit().remove("pending").apply()
   }
  } catch (_:Exception) { /* Retain text until an editor is focused again. */ }
 }
 override fun onWindowShown() {
  super.onWindowShown()
  voiceHandler.postDelayed({ deliverPendingVoice() },200)
 }
 override fun onCreateInputView():View { board=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; build(); return board }
 override fun onStartInputView(info:EditorInfo?,restarting:Boolean) {
  super.onStartInputView(info,restarting)
  val input=info?.inputType ?: 0
  val kind=input and InputType.TYPE_MASK_CLASS
  val variation=input and InputType.TYPE_MASK_VARIATION
  numeric=kind==InputType.TYPE_CLASS_NUMBER || kind==InputType.TYPE_CLASS_PHONE || kind==InputType.TYPE_CLASS_DATETIME
  secureField=((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING != 0) || (kind==InputType.TYPE_CLASS_TEXT && variation in listOf(
   InputType.TYPE_TEXT_VARIATION_PASSWORD,
   InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
   InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
  )) || (kind==InputType.TYPE_CLASS_NUMBER && variation==InputType.TYPE_NUMBER_VARIATION_PASSWORD)
  dismissKeyPreview(); emojiPage=false; symbols=false; shift=false; capsLocked=false; pending=""; composingActive=false; lastTyped=""; lastSpaceAt=0L; lastCommittedSpace=false
  if(::board.isInitialized) build()
  if(!secureField) saveCurrentClipboard()
  voiceHandler.postDelayed({ deliverPendingVoice() },150)
 }
 private fun background():Drawable {
  val animated=prefs.getString("theme","Portrait Fire") ?: "Portrait Fire"
  if(animated.startsWith("Animated ")) return AnimatedThemeDrawable(animated)
  if(!secureField && prefs.getString("theme","Portrait Fire")=="Portrait Fire") {
   val picture=resources.getDrawable(R.drawable.alam_portrait_bg,theme).mutate()
   val dim=prefs.getInt("portrait_dim",18).coerceIn(0,85)*255/100
   return LayerDrawable(arrayOf(picture,ColorDrawable(Color.argb(dim,0,0,0))))
  }; val selectedTheme=prefs.getString("theme","Portrait Fire") ?: "Portrait Fire"; val colors=customThemeColors(selectedTheme)?.let { intArrayOf(it[0],it[1]) } ?: when(selectedTheme) { "Rainbow RGB"->intArrayOf(0xff090c1c.toInt(),0xff26103a.toInt()); "Electric Blue"->intArrayOf(0xff021629.toInt(),0xff073c5c.toInt()); "Purple Glass"->intArrayOf(0xff321a4c.toInt(),0xff694b82.toInt()); "AMOLED"->intArrayOf(Color.BLACK,Color.BLACK); "White"->intArrayOf(0xfff8fafc.toInt(),0xffe3e8f0.toInt()); "Light"->intArrayOf(0xffe8edf4.toInt(),0xffcbd5e1.toInt()); "Neon"->intArrayOf(0xff230b52.toInt(),0xff7c1c90.toInt()); "Glass"->intArrayOf(0xff7c95b3.toInt(),0xffb7d3e6.toInt()); "3D"->intArrayOf(0xff394150.toInt(),0xff141b2b.toInt()); "Portrait Fire"->intArrayOf(0xff080305.toInt(),0xff220008.toInt()); "Red Neon"->intArrayOf(0xff090909.toInt(),0xff160005.toInt()); "Blue Neon"->intArrayOf(0xff03132d.toInt(),0xff020713.toInt()); "Gold"->intArrayOf(0xff28200c.toInt(),0xff080808.toInt()); "Green Matrix"->intArrayOf(0xff02170a.toInt(),0xff030603.toInt()); else->intArrayOf(0xff252b39.toInt(),0xff111827.toInt()) }; if(selectedTheme=="Photo") { try { val uri=android.net.Uri.parse(prefs.getString("photo", "")); val stream=contentResolver.openInputStream(uri); val bmp=BitmapFactory.decodeStream(stream); stream?.close(); if(bmp!=null) return BitmapDrawable(resources,bmp).apply { alpha=(prefs.getInt("opacity",35)*255/100).coerceIn(0,255); gravity=android.view.Gravity.FILL } } catch(_:Exception) {} }; return GradientDrawable(GradientDrawable.Orientation.TL_BR,colors) }
 private fun customThemeColors(name:String):IntArray? = when(name) {
  "Cyber Cyan" -> intArrayOf(0xff04121c.toInt(),0xff003f54.toInt(),0xff00eaff.toInt())
  "Ice Crystal" -> intArrayOf(0xff0b1b30.toInt(),0xff29536e.toInt(),0xffb5f3ff.toInt())
  "Crimson Storm" -> intArrayOf(0xff170308.toInt(),0xff520717.toInt(),0xffff234f.toInt())
  "Rose Hearts" -> intArrayOf(0xff29071b.toInt(),0xff6c2145.toInt(),0xffff75b5.toInt())
  "Violet Galaxy" -> intArrayOf(0xff0d092c.toInt(),0xff392070.toInt(),0xffab83ff.toInt())
  "Midnight Steel" -> intArrayOf(0xff080d15.toInt(),0xff283d55.toInt(),0xffa6c6ff.toInt())
  "Golden Crown" -> intArrayOf(0xff241408.toInt(),0xff61410d.toInt(),0xffffd66a.toInt())
  "Emerald Glow" -> intArrayOf(0xff06180f.toInt(),0xff145d3d.toInt(),0xff48ff9a.toInt())
  "Forest Moss" -> intArrayOf(0xff102111.toInt(),0xff39522a.toInt(),0xffc6f47c.toInt())
  "Ocean Wave" -> intArrayOf(0xff031a29.toInt(),0xff08617a.toInt(),0xff45dfff.toInt())
  "Orange Flame" -> intArrayOf(0xff280a03.toInt(),0xff74300a.toInt(),0xffff9b32.toInt())
  "Pink Candy" -> intArrayOf(0xff260a23.toInt(),0xff6a2b6b.toInt(),0xffff91f0.toInt())
  "Ruby Glass" -> intArrayOf(0xff20030d.toInt(),0xff67102d.toInt(),0xffff5e89.toInt())
  "Electric Lime" -> intArrayOf(0xff111b03.toInt(),0xff466808.toInt(),0xffb9ff26.toInt())
  "Royal Indigo" -> intArrayOf(0xff0c0a26.toInt(),0xff2d2470.toInt(),0xff8f86ff.toInt())
  "Silver Chrome" -> intArrayOf(0xff1b2029.toInt(),0xff647182.toInt(),0xffe5efff.toInt())
  "Cherry Blossom" -> intArrayOf(0xff2a1426.toInt(),0xff6e3859.toInt(),0xffffb4db.toInt())
  "Aqua Glass" -> intArrayOf(0xff071f25.toInt(),0xff246674.toInt(),0xff79f5ed.toInt())
  "Black Panther" -> intArrayOf(0xff040509.toInt(),0xff171e2d.toInt(),0xff6579ff.toInt())
  "Sunset Glow" -> intArrayOf(0xff260b1a.toInt(),0xff763020.toInt(),0xffffb75d.toInt())
  "Neon Sakura" -> intArrayOf(0xff200920.toInt(),0xff58245b.toInt(),0xffff68d8.toInt())
  "Deep Space" -> intArrayOf(0xff030b1d.toInt(),0xff172f58.toInt(),0xff57aaff.toInt())
  "Purple Lightning" -> intArrayOf(0xff130323.toInt(),0xff4b146b.toInt(),0xffd55bff.toInt())
  "Blue Black" -> intArrayOf(0xff020b15.toInt(),0xff0a385b.toInt(),0xff00aaff.toInt())
  else -> null
 }
 private fun key(text:String,weight:Float=1f, action:()->Unit):Button {
  val theme=prefs.getString("theme","Portrait Fire") ?: "Portrait Fire"
  val accent=customThemeColors(theme)?.get(2) ?: when(theme) { "Blue Neon","Electric Blue"->0xff00bbff.toInt(); "Rainbow RGB"->0xffff4bc3.toInt(); "Purple Glass"->0xffe68cff.toInt(); "AMOLED"->0xffb9b9b9.toInt(); "White"->0xff74839b.toInt(); "Gold"->0xffffc247.toInt(); "Green Matrix"->0xff00df68.toInt(); "Neon"->0xffca4bff.toInt(); "Glass"->0xffc2e9ff.toInt(); "3D"->0xff90a7c8.toInt(); "Light"->0xff7185a9.toInt(); "Portrait Fire"->0xffff4054.toInt(); else->0xffe00024.toInt() }
  val glow=prefs.getInt("glow",85)
  val height=if(numeric) prefs.getInt("banking_key_height",62).coerceIn(40,132) else if(bangla && !symbols) prefs.getInt("bangla_key_height",46).coerceIn(40,65) else prefs.getInt("height",58).coerceIn(44,76)
  return Button(this).apply {
   this.text=text; textSize=prefs.getInt("font",18).toFloat(); isAllCaps=false
   typeface=android.graphics.Typeface.create(
    when(theme) {
     "Golden Crown","Gold","Silver Chrome" -> "serif"
     "Cyber Cyan","Electric Blue","Blue Neon","Deep Space" -> "sans-serif-condensed"
     "Rose Hearts","Pink Candy","Cherry Blossom" -> "sans-serif-light"
     else -> "sans-serif-medium"
    },android.graphics.Typeface.BOLD)
   setTextColor(if(theme=="Light" || theme=="White") Color.BLACK else Color.WHITE)
   val neon=NeonKeyDrawable(accent,theme=="Light" || theme=="White",glow,theme)
   background=neon
   if(!secureField && !prefs.getBoolean("low_ram",false) && prefs.getBoolean("ambient_fire",true)) { neon.animated=true; animatedKeys.add(neon) }
   elevation=(glow/14f).coerceAtMost(9f)
   stateListAnimator=null
   setOnTouchListener { _,event ->
    when(event.actionMasked) {
     MotionEvent.ACTION_DOWN -> {
      // Instant visual response without starting an animator for every keystroke.
      val palette=intArrayOf(0xff00e5ff.toInt(),0xffffd54f.toInt(),0xffff4fa3.toInt(),0xff7cff6b.toInt(),0xffae83ff.toInt(),0xffff754a.toInt())
      neon.pressColor=palette[((android.os.SystemClock.uptimeMillis()/97L + text.hashCode().toLong()).rem(palette.size.toLong()).toInt()+palette.size)%palette.size]
      neon.pressedGlow=true
      showKeyPreview(this,text.toString())
     }
     MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL -> {
      neon.pressedGlow=false
      previewHandler.postDelayed(closePreview,55L)
     }
    }; false
   }
   setOnClickListener {
    if(prefs.getBoolean("vibrate",false)) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    if(prefs.getBoolean("key_sound",false)) {
     (getSystemService(Context.AUDIO_SERVICE) as? AudioManager)?.playSoundEffect(AudioManager.FX_KEY_CLICK,0.35f)
    }
    if(!secureField && prefs.getBoolean("fire_lightning",true) && glow>0 && !prefs.getBoolean("low_ram",false)) {
     // Short, non-blocking feedback; no per-tap ValueAnimator allocations.
     animate().cancel()
     scaleX=0.97f; scaleY=0.97f
     animate().scaleX(1f).scaleY(1f).setDuration(65L).start()
    }
    action()
   }
   // Theme-specific key spacing changes the silhouette without shrinking touch targets.
   val horizontalGap=when(theme) {
    "Glass","Purple Glass","Aqua Glass","Rose Hearts","Pink Candy" -> 3
    "AMOLED","Green Matrix","Electric Lime" -> 1
    "3D","Midnight Steel","Black Panther","Silver Chrome" -> 2
    else -> 2
   }
   layoutParams=LinearLayout.LayoutParams(0,height.dp,weight).apply { setMargins(horizontalGap.dp,2.dp,horizontalGap.dp,2.dp) }
   minWidth=0; minHeight=0; setPadding(0,0,0,0)
  }
 }
 private fun compactTool(label:String,action:()->Unit):Button = key(label,1f,action).apply {
  textSize=13f
  layoutParams=LinearLayout.LayoutParams(0,32.dp,1f).apply { setMargins(1.dp,1.dp,1.dp,1.dp) }
 }
 private fun changeFontSize(delta:Int) {
  val current=prefs.getInt("font",18).coerceIn(12,28)
  val next=(current+delta).coerceIn(12,28)
  if(next!=current) { prefs.edit().putInt("font",next).apply(); build() }
 }
 private fun changeKeyHeight(delta:Int) {
  val current=prefs.getInt("height",58).coerceIn(44,76)
  val next=(current+delta).coerceIn(44,76)
  if(next!=current) { prefs.edit().putInt("height",next).apply(); build() }
 }
 private val Int.dp:Int get()=(this*resources.displayMetrics.density).toInt()
 private fun row(keys:List<String>,action:(String)->Unit) { val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }; keys.forEach { k -> r.addView(key(k) { action(k) }) }; board.addView(r) }
 private fun commit(s:String) { currentInputConnection?.commitText(s,1) }
 private fun insertSpace() {
  flushBanglish()
  val now=android.os.SystemClock.uptimeMillis()
  if(prefs.getBoolean("double_space_period",true) && now-lastSpaceAt<420L && !secureField) {
   val before=currentInputConnection?.getTextBeforeCursor(2,0)?.toString().orEmpty()
   if(before.endsWith(" ") && before.length>1 && before[before.length-2].isLetterOrDigit()) {
    currentInputConnection?.deleteSurroundingText(1,0)
    commit(if(bangla||banglish) "। " else ". ")
   } else commit(" ")
  } else commit(" ")
  lastSpaceAt=now; lastTyped=""; lastCommittedSpace=true; updateSuggestions()
 }
 private fun flushBanglish() {
  if(pending.isNotEmpty()) {
   if(composingActive) currentInputConnection?.finishComposingText()
   else currentInputConnection?.commitText(Banglish.convert(pending),1)
   pending=""; composingActive=false
  }
 }
 private fun typeLetter(s:String) {
  lastTyped += s
  lastSpaceAt=0L; lastCommittedSpace=false
  if(banglish && !symbols && !numeric && !secureField) {
   pending+=s.lowercase()
   composingActive=true
   currentInputConnection?.setComposingText(Banglish.convert(pending),1)
  } else commit(s)
  if(shift && !capsLocked && !bangla && !banglish && !symbols) { shift=false; refreshLetterLabels() }
  updateSuggestions()
 }
 private fun toggleShift() {
  val now=android.os.SystemClock.uptimeMillis()
  if(now-lastShiftTap<350L) { capsLocked=!capsLocked; shift=capsLocked }
  else { capsLocked=false; shift=!shift }
  lastShiftTap=now
  build()
 }
 private fun refreshLetterLabels() {
  // Refresh only the displayed key labels, without rebuilding the whole keyboard.
  fun scan(view:View) {
   if(view is Button && view.text.length==1 && view.text[0].lowercaseChar() in 'a'..'z') view.text=if(shift) view.text.toString().uppercase() else view.text.toString().lowercase()
   if(view is android.view.ViewGroup) for(i in 0 until view.childCount) scan(view.getChildAt(i))
  }
  if(::board.isInitialized) scan(board)
 }
 private fun erase() {
  lastSpaceAt=0L
  lastTyped=lastTyped.dropLast(1)
  if(banglish && pending.isNotEmpty() && composingActive) {
   pending=pending.dropLast(1)
   if(pending.isEmpty()) { currentInputConnection?.setComposingText("",1); currentInputConnection?.finishComposingText(); composingActive=false }
   else currentInputConnection?.setComposingText(Banglish.convert(pending),1)
  } else {
   // Delete one Unicode code point, not one UTF-16 code unit. This keeps emoji
   // and supplementary characters from being split into invalid halves.
   val connection=currentInputConnection
   if (connection != null) {
    val deleted=try { connection.deleteSurroundingTextInCodePoints(1,0) } catch (_:Exception) { false }
    if (!deleted) connection.deleteSurroundingText(1,0)
   }
  }
  updateSuggestions()
 }
 private fun switchLanguage() { lastTyped=""; flushBanglish(); when { banglish -> { banglish=false; bangla=true }; bangla -> { bangla=false; banglish=false }; else -> { banglish=true; bangla=false } }; build() }
 private fun build() {
  stopAmbient(); board.removeAllViews(); board.background=background(); board.setPadding(4.dp,4.dp,4.dp,7.dp)
  // Keep the menu avatar inside the suggestion/search strip, not in a separate toolbar.
  if(emojiPage && !numeric && !secureField) { renderEmojiPage(); return }
  suggestionStrip=null
  if(!numeric && !secureField) {
   val strip=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
   val avatar=ImageView(this).apply {
    setImageResource(R.mipmap.ic_launcher)
    scaleType=ImageView.ScaleType.CENTER_CROP
    background=GradientDrawable().apply { cornerRadius=18.dp.toFloat(); setStroke(2.dp,0xffff2028.toInt()) }
    clipToOutline=true
    contentDescription="All keyboard functions"
    setOnClickListener { showAllKeyboardTools(this) }
   }
   strip.addView(avatar,LinearLayout.LayoutParams(32.dp,32.dp))
   strip.addView(TextView(this).apply {
    text="🎙"; textSize=22f; gravity=Gravity.CENTER; contentDescription="Voice typing"
    setTextColor(Color.WHITE); setOnClickListener { launchVoice() }
   },LinearLayout.LayoutParams(42.dp,34.dp))
   if(prefs.getBoolean("suggestion_row",true)) {
    suggestionStrip=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
    strip.addView(suggestionStrip,LinearLayout.LayoutParams(0,34.dp,1f))
   }
   board.addView(strip)
   updateSuggestions()
  }
  if(numeric) {
   // Banking/amount fields: independently adjustable key height.
   val sizeBar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
   val sizeLabel=TextView(this).apply {
    text="Banking size: ${prefs.getInt("banking_key_height",62).coerceIn(40,132)}dp"
    setTextColor(Color.WHITE); textSize=13f; gravity=Gravity.CENTER
   }
   fun adjustBanking(delta:Int) {
    val old=prefs.getInt("banking_key_height",62).coerceIn(40,132)
    prefs.edit().putInt("banking_key_height",(old+delta).coerceIn(40,132)).apply()
    build()
   }
   sizeBar.addView(key("−",0.7f) { adjustBanking(-5) }.apply { layoutParams=LinearLayout.LayoutParams(0,40.dp,1f) })
   sizeBar.addView(sizeLabel,LinearLayout.LayoutParams(0,40.dp,3f))
   sizeBar.addView(key("+",0.7f) { adjustBanking(5) }.apply { layoutParams=LinearLayout.LayoutParams(0,40.dp,1f) })
   sizeBar.addView(key("Reset",1f) { prefs.edit().putInt("banking_key_height",62).apply(); build() }.apply { layoutParams=LinearLayout.LayoutParams(0,40.dp,2f) })
   board.addView(sizeBar)
   val action=currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
   val decimal=(currentInputEditorInfo?.inputType ?: 0) and InputType.TYPE_NUMBER_FLAG_DECIMAL != 0
   val signed=(currentInputEditorInfo?.inputType ?: 0) and InputType.TYPE_NUMBER_FLAG_SIGNED != 0
   fun advance() {
    val ic=currentInputConnection ?: return
    if(action==EditorInfo.IME_ACTION_NEXT || action==EditorInfo.IME_ACTION_PREVIOUS || action==EditorInfo.IME_ACTION_DONE || action==EditorInfo.IME_ACTION_GO || action==EditorInfo.IME_ACTION_SEND || action==EditorInfo.IME_ACTION_SEARCH) {
     ic.performEditorAction(action)
    } else {
     // Many bank forms do not specify IME_ACTION_NEXT; request focus movement anyway.
     ic.performEditorAction(EditorInfo.IME_ACTION_NEXT)
    }
   }
   listOf(listOf("1","2","3"),listOf("4","5","6"),listOf("7","8","9")).forEach { digits ->
    val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
    digits.forEach { digit -> line.addView(key(digit) { commit(digit) }) }
    board.addView(line)
   }
   val bottomNumeric=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   bottomNumeric.addView(key(if(decimal) "." else if(signed) "−" else ",") {
    if(decimal) commit(".") else if(signed) commit("-") else commit(",")
   })
   bottomNumeric.addView(key("0") { commit("0") })
   bottomNumeric.addView(deleteKey())
   board.addView(bottomNumeric)
   val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   actions.addView(key("Next  →",2.5f) { advance() })
   actions.addView(key("✓ Done",1.5f) { currentInputConnection?.performEditorAction(EditorInfo.IME_ACTION_DONE) })
   board.addView(actions)
   startAmbient()
   return
  }
  // Always-visible number row, like the requested red-neon reference.
  if(!secureField && prefs.getBoolean("number_row",true)) {
   val numbers=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   val alternate=listOf("!","@","#","$","%","^","&","*","(",")")
   (if(bangla) "১২৩৪৫৬৭৮৯০" else "1234567890").forEachIndexed { index,digit ->
    numbers.addView(key(digit.toString()) { flushBanglish(); commit(digit.toString()); updateSuggestions() }.apply {
     contentDescription="Number $digit; hold for ${alternate[index]}"
     setOnLongClickListener { flushBanglish(); commit(alternate[index]); updateSuggestions(); true }
    })
   }
   board.addView(numbers)
  }
  val rows=if(symbols && extraSymbols) listOf("€£¥৳₹₩₽¢", "©®™✓✔✗×÷", "°•…—–§¶†‡", "≤≥≠≈∞√π∆") else if(symbols) listOf("@#₹৳%&*()-", "/;:!?.,+=", "\\|~^_[]{}") else if(bangla) listOf("অআইঈউঊএঐওঔ", "কখগঘঙচছজঝঞ", "টঠডঢণতথদধন", "পফবভমযরলশষস") else listOf("qwertyuiop","asdfghjkl")
  rows.forEach { chars -> row(chars.map { if(shift && !bangla && !symbols) it.uppercaseChar().toString() else it.toString() }) { k -> typeLetter(if(shift && !bangla && !symbols) k.uppercase() else k) } }
  if(bangla && !symbols) {
   // Bengali combining signs belong in a compact, legible row, never a squeezed 20-key row.
   val signs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   listOf("া","ি","ী","ু","ূ","ে","ৈ","ো","ৌ","্").forEach { mark ->
    signs.addView(key(mark) { typeLetter(mark) }.apply { textSize=20f })
   }
   board.addView(signs)
  }
  if(!symbols && !bangla) {
   val letters=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   letters.addView(key(if(capsLocked) "⇪" else "⬆",1.25f) { toggleShift() })
   "zxcvbnm".forEach { c -> letters.addView(key(if(shift) c.uppercaseChar().toString() else c.toString()) { typeLetter(if(shift) c.uppercaseChar().toString() else c.toString()) }) }
   letters.addView(deleteKey().apply { layoutParams=LinearLayout.LayoutParams(0,prefs.getInt("height",58).dp,1.25f).apply { setMargins(1.dp,2.dp,1.dp,2.dp) } })
   board.addView(letters)
  } else if(!symbols) {
   val controls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   controls.addView(key("আরও") {
    val popup=PopupMenu(this,controls)
    listOf("হ","ড়","ঢ়","য়","ং","ঃ","ঁ","ৎ","ঋ","ৠ","ৡ","ৗ","৳","।","॥").forEachIndexed { index,letter -> popup.menu.add(0,index,index,letter) }
    popup.setOnMenuItemClickListener { item -> typeLetter(item.title.toString()); true }
    popup.show()
   })
   controls.addView(deleteKey())
   board.addView(controls)
  }
  if(symbols) {
   val edit=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   edit.addView(key("ABC",2f) { symbols=false; extraSymbols=false; build() })
   edit.addView(key(if(extraSymbols) "1/2" else "2/2",1.3f) { extraSymbols=!extraSymbols; build() })
   edit.addView(deleteKey().apply { layoutParams=LinearLayout.LayoutParams(0,prefs.getInt("height",58).dp,1.5f).apply { setMargins(1.dp,2.dp,1.dp,2.dp) } })
   board.addView(edit)
  }
  val bottom=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  bottom.addView(key("?123") { flushBanglish(); symbols=!symbols; extraSymbols=false; build() })
  bottom.addView(key("😊") { showEmoji() })
  bottom.addView(key(",") { flushBanglish(); lastTyped=""; commit(","); updateSuggestions() }.apply {
   contentDescription="Comma; hold for punctuation"
   setOnLongClickListener {
    val popup=PopupMenu(this@KeyboardService,this)
    listOf(".","?","!",";",":","'", "\"").forEachIndexed { index,mark -> popup.menu.add(0,index,index,mark) }
    popup.setOnMenuItemClickListener { item ->
     val mark=popup.menu.findItem(item.itemId)?.title?.toString().orEmpty()
     flushBanglish(); commit(mark); updateSuggestions(); true
    }
    popup.show(); true
   }
  })
  bottom.addView(key(if(banglish) "Banglish" else if(bangla) "বাংলা" else "English",3.5f) { insertSpace() }.apply {
   setOnLongClickListener {
    val popup=PopupMenu(this@KeyboardService,this)
    popup.menu.add(0,1,0,"Move cursor left")
    popup.menu.add(0,2,1,"Move cursor right")
    popup.setOnMenuItemClickListener { item -> flushBanglish(); currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,if(item.itemId==1) android.view.KeyEvent.KEYCODE_DPAD_LEFT else android.view.KeyEvent.KEYCODE_DPAD_RIGHT)); currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP,if(item.itemId==1) android.view.KeyEvent.KEYCODE_DPAD_LEFT else android.view.KeyEvent.KEYCODE_DPAD_RIGHT)); true }
    popup.show(); true
   }
  })
  bottom.addView(key(".") { flushBanglish(); lastTyped=""; commit("."); updateSuggestions() })
  bottom.addView(key("🌐") { symbols=false; switchLanguage() })
  bottom.addView(key("↵") { flushBanglish(); lastTyped=""; updateSuggestions(); val action=currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE; if(action==EditorInfo.IME_ACTION_NONE || action==EditorInfo.IME_ACTION_UNSPECIFIED || action==EditorInfo.IME_ACTION_NONE) commit("\n") else currentInputConnection?.performEditorAction(action) })
  board.addView(bottom)
  startAmbient()
 }
 private val englishWords by lazy { listOf("hello","help","happy","how","house","good","great","going","thanks","thank","please","people","keyboard","beautiful","morning","night","today","tomorrow","love","later","okay","fine","friend","welcome","where","what","when","why","who","work","working","world","wonderful","message","meeting","money","mobile","number","name","nice","need","new","never","yes","you","your","yesterday","school","student","teacher","time","take","talk","tell","thankful","sorry","see","send","share","save","safe","reply","right","really","ready","phone","photo","picture","perfect","open","online","offline","okay","morning","evening","afternoon","family","father","mother","brother","sister","home","hope","have","has","had","here","there","this","that","these","those","today","tonight","tomorrow","tomorrow","very","video","voice","typing","text","theme","beautiful","best","better","because","before","after","again","always","awesome","amazing","android","application","app","account","address","answer","available","busy","business","call","can","cannot","change","check","come","coming","contact","correct","custom","day","dear","done","download","easy","email","english","example","fast","feel","first","free","from","give","glad","go","goodbye","great","happy","hi","important","information","just","keep","kind","know","language","last","learn","let","like","little","long","look","looking","make","many","maybe","more","most","much","my","next","now","please","quick","question","read","remember","right","say","search","settings","show","simple","small","smart","some","something","start","stop","style","support","sure","system","test","thank","thanks","them","then","think","through","try","update","use","using","want","welcome","well","will","with","without","write","writing") }
 private val romanWords by lazy { listOf("ami","amra","amar","amake","apni","apnar","apnake","tumi","tomar","tomake","valo","bhalo","achi","acho","achen","kemon","ki","korcho","koro","korbo","kori","dhonnobad","bangla","bangladesh","assalamualaikum","salam","shuvo","sundor","onek","onk","hobe","hoy","na","ha","ekhon","aj","kal","porer","age","pore","bari","basha","basa","kotha","kothay","jabo","jabe","jao","aso","asbo","khabo","khawa","pani","khub","bondhu","taka","number","nam","likho","likhi","dao","daw","dekho","eta","ota","seta","jeta","ekhane","okhane","rat","din","sokal","dupure","please","sorry","hello","hi","bhalobashi","valobashi","shob","sob","kichu","kisu","kintu","keno","kokhon","kothao","kivabe","kemne","jodi","tahole","amader","tomader","oder","oderke","bujhi","bujhlam","bujhte","chao","chai","chilo","chole","cholo","chinta","dorkar","dibo","dibe","dilen","dite","doya","ekta","eita","evabe","ghor","ghum","ghumao","hocche","hoise","hoyechhe","jante","jani","jano","jibon","kaj","kaje","kajer","karon","khobor","khushi","lagbe","lagche","lage","likhe","mone","mon","moja","notun","purono","proyojon","somoy","shomoy","sotti","thakbe","thaki","thako","thik","thikache","tobe","valo","bhalo","abar","ajke","agami","ratri","shokal","dupure","bikel","shondha") }
 private val nextEnglish by lazy { mapOf(
  "good" to listOf("morning","night","luck"),
  "thank" to listOf("you"), "how" to listOf("are","much","many"),
  "i" to listOf("am","will","have"), "see" to listOf("you"),
  "happy" to listOf("birthday","day"), "please" to listOf("help","send"),
  "my" to listOf("name","friend","phone"),
  "are" to listOf("you","we","they"), "can" to listOf("you","we","i"),
  "have" to listOf("a","you","been"), "see" to listOf("you","this","that"),
  "will" to listOf("be","you","send"), "good" to listOf("morning","night","luck")
 ) }
 private val nextBanglish by lazy { mapOf(
  "ami" to listOf("valo","achi","jabo"),
  "tumi" to listOf("kemon","ki","valo"),
  "amar" to listOf("nam","bari","bondhu"),
  "onek" to listOf("valo","sundor"),
  "ki" to listOf("korcho","hobe"),
  "valo" to listOf("achi","theko"),
  "apni" to listOf("kemon","ki","valo"), "aj" to listOf("ami","ki","onek"),
  "kal" to listOf("ami","jabo","dekha"), "tomar" to listOf("nam","bari","kotha")
 ) }
 private val bengaliWords by lazy { listOf("আমি","আমরা","আমার","আমাকে","আপনি","আপনার","তুমি","তোমার","সে","তিনি","ভালো","ভাল","আছি","আছেন","আছো","কেমন","কী","কি","কেন","কখন","কোথায়","কোথায়","কিভাবে","কীভাবে","কাজ","করছি","করছে","করবে","করবেন","করো","করি","করতে","ধন্যবাদ","বাংলা","বাংলাদেশ","আসসালামু","আলাইকুম","সুন্দর","অনেক","হবে","হয়","হয়","না","হ্যাঁ","এখন","আজ","কাল","আগে","পরে","বাড়ি","বাড়ি","বাসা","কথা","যাব","যাবে","যাই","আসো","আসব","খাব","পানি","খুব","বন্ধু","টাকা","নাম","লিখে","দাও","দেখো","এটা","ওটা","এখানে","ওখানে","রাত","দিন","সকাল","দুপুর","ভালোবাসি","সব","কিছু","কিন্তু","যদি","তাহলে","আমাদের","বুঝেছি","চাই","চলো","দরকার","দিব","দিতে","একটা","ঘর","ঘুম","হচ্ছে","জীবন","খবর","খুশি","লাগবে","মনে","মন","মজা","নতুন","পুরোনো","প্রয়োজন","প্রয়োজন","সময়","সময়","সত্যি","থাকবে","ঠিক","আবার","আগামী","বিকেল","সন্ধ্যা","শুভ","স্বাগতম","অভিনন্দন","শিক্ষক","শিক্ষার্থী","স্কুল","পরিবার","মোবাইল","ফোন","বার্তা","সাহায্য") }
 private fun editDistanceOne(a:String,b:String):Boolean {
  if(kotlin.math.abs(a.length-b.length)>1) return false
  var i=0; var j=0; var errors=0
  while(i<a.length && j<b.length) {
   if(a[i]==b[j]) { i++; j++ } else {
    errors++; if(errors>1) return false
    if(a.length>b.length) i++ else if(b.length>a.length) j++ else { i++; j++ }
   }
  }
  return errors+(a.length-i)+(b.length-j)<=1
 }
 private fun updateSuggestions() {
  val strip=suggestionStrip ?: return
  strip.removeAllViews()
  // Read the actual editor text so predictions also work after cursor movement,
  // pasting, or returning to an existing word. Never inspect protected fields.
  val editorToken=if(secureField) "" else try {
   currentInputConnection?.getTextBeforeCursor(48,0)?.toString().orEmpty().takeLastWhile { it.isLetter() }
  } catch(_:Exception) { "" }
  val token=if(banglish && pending.isNotEmpty()) pending.lowercase() else editorToken.lowercase()
  val before=if(secureField) "" else try { currentInputConnection?.getTextBeforeCursor(96,0)?.toString().orEmpty() } catch(_:Exception) { "" }
  val previous=if(token.isEmpty()) before.trimEnd().trimEnd { !it.isLetter() }.takeLastWhile { it.isLetter() }.lowercase() else ""
  val contextual=if(banglish) nextBanglish[previous] else nextEnglish[previous]
  val customWords=prefs.getString("custom_words", "").orEmpty().split("\n").filter { it.isNotBlank() }
  val dictionary=if(bangla) bengaliWords else if(banglish) romanWords else englishWords
  val words=if(token.isEmpty()) {
   if(bangla) listOf("আমি","তুমি","ভালো","ধন্যবাদ") else (contextual ?: if(banglish) listOf("ami","tumi","valo","bangla") else listOf("Hello","Thanks","Alam","Bangla"))
  } else {
   val candidates=(customWords+dictionary).distinct()
   val matching=candidates.filter { it.startsWith(token,ignoreCase=true) }.take(4)
   if(matching.isNotEmpty()) matching else (listOf(token)+candidates.filter { it.length>=2 && editDistanceOne(token,it) }.take(3)).distinct()
  }
  words.forEach { word ->
   val display=if(banglish) Banglish.convert(word) else word
   strip.addView(TextView(this).apply {
    text=display; gravity=android.view.Gravity.CENTER; textSize=if(bangla) 17f else 15f; setTextColor(Color.WHITE)
    setShadowLayer(4f,0f,0f,0xffff2323.toInt())
    setOnClickListener {
     if(banglish && composingActive) { pending=""; composingActive=false; currentInputConnection?.setComposingText(display,1); currentInputConnection?.finishComposingText() }
     else if(token.isNotEmpty()) {
      currentInputConnection?.deleteSurroundingText(token.length,0)
      commit(display)
     }
     else commit(display)
     commit(" "); lastTyped=""; updateSuggestions()
    }
   },LinearLayout.LayoutParams(0,34.dp,1f))
  }
 }
 private fun showQuickThemes() {
  if(secureField) return
  val anchor=board.getChildAt(0)
  val popup=PopupMenu(this,anchor)
  val themes=listOf("Portrait Fire","Red Neon","Rainbow RGB","Electric Blue","Blue Neon","Neon","Purple Glass","Gold","Green Matrix","Glass","3D","AMOLED","White","Dark","Light","Photo","Cyber Cyan","Ice Crystal","Crimson Storm","Rose Hearts","Violet Galaxy","Midnight Steel","Golden Crown","Emerald Glow","Forest Moss","Ocean Wave","Orange Flame","Pink Candy","Ruby Glass","Electric Lime","Royal Indigo","Silver Chrome","Cherry Blossom","Aqua Glass","Black Panther","Sunset Glow","Neon Sakura","Deep Space","Purple Lightning","Blue Black","Animated Aurora","Animated Fire","Animated Galaxy","Animated Rain","Animated Hearts","Animated Forest")
  themes.forEachIndexed { index,name -> popup.menu.add(0,index,index,name) }
  popup.menu.add(1,100,100,"Advanced theme settings")
  popup.setOnMenuItemClickListener { item ->
   if(item.itemId==100) openSettings()
   else themes.getOrNull(item.itemId)?.let { selected ->
    prefs.edit().putString("theme",selected).apply()
    build()
   }
   true
  }
  popup.show()
 }
 private fun openSettings() { startActivity(Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
 private fun clipboardHistory():MutableList<String> {
  val data=prefs.getString("clipboard_history", "") ?: ""
  return data.split("\u001e").filter { it.isNotBlank() }.toMutableList()
 }
 private fun saveCurrentClipboard() {
  if(secureField) return
  val text=try {
   if(!clipManager.hasPrimaryClip()) return
   val clip=clipManager.primaryClip ?: return
   if(clip.itemCount==0) return
   clip.getItemAt(0).coerceToText(this).toString()
  } catch (_:Exception) { return }
  if(text.isBlank() || text.length>5000 || text.contains('\u001e')) return
  val history=clipboardHistory()
  history.remove(text)
  history.add(0,text)
  prefs.edit().putString("clipboard_history",history.take(50).joinToString("\u001e")).apply()
 }
 private fun showClipboard() {
  if(secureField) return
  saveCurrentClipboard()
  val items=clipboardHistory()
  if(items.isEmpty()) { Toast.makeText(this,"No saved clipboard items",Toast.LENGTH_SHORT).show(); return }
  val container=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12.dp,8.dp,12.dp,8.dp) }
  val scroll=ScrollView(this)
  val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
  scroll.addView(list)
  container.addView(scroll,LinearLayout.LayoutParams(-1,340.dp))
  val dialog=android.app.AlertDialog.Builder(this).setTitle("Clipboard history (${items.size}/50)").setView(container)
   .setNegativeButton("Close",null)
   .setNeutralButton("Clear all") { _,_ -> prefs.edit().remove("clipboard_history").apply() }.create()
  dialog.window?.setType(android.view.WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG)
  items.forEach { value ->
   val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
   val preview=TextView(this).apply {
    text=value.replace('\n',' ').take(85); textSize=15f; setPadding(8.dp,12.dp,8.dp,12.dp)
    setOnClickListener { flushBanglish(); commit(value); dialog.dismiss() }
   }
   line.addView(preview,LinearLayout.LayoutParams(0,-2,1f))
   line.addView(Button(this).apply {
    text="✕"; contentDescription="Delete clipboard item"
    setOnClickListener {
     val remaining=clipboardHistory(); remaining.remove(value)
     prefs.edit().putString("clipboard_history",remaining.joinToString("\u001e")).apply()
     list.removeView(line)
    }
   },LinearLayout.LayoutParams(56.dp,52.dp))
   list.addView(line)
  }
  try { dialog.show(); dialog.window?.setLayout((resources.displayMetrics.widthPixels*.9f).toInt(),-2) }
  catch (_:Exception) { Toast.makeText(this,"Clipboard unavailable",Toast.LENGTH_SHORT).show() }
 }
 private fun showAiTools() {
  if(secureField) return
  val anchor=board.getChildAt(0)
  val popup=PopupMenu(this,anchor)
  val labels=listOf("Text: UPPERCASE", "Text: lowercase", "Text: Sentence case", "Text: Add full stop", "Quick reply: Thank you!", "Quick reply: ধন্যবাদ!", "Quick reply: ঠিক আছে", "Greeting: আসসালামু আলাইকুম", "Quick reply: I will get back to you soon.", "Quick reply: আমি একটু পরে জানাচ্ছি।", "Quick reply: Please send the details.", "Rewrite: Polite English", "Rewrite: Formal English", "Rewrite: Friendly English", "Rewrite: Polite Bangla", "Rewrite: Add greeting")
  labels.forEachIndexed { index,label -> popup.menu.add(0,index,index,label) }
  popup.setOnMenuItemClickListener { item ->
   val selected=currentInputConnection?.getSelectedText(0)?.toString().orEmpty().trim()
   when(item.itemId) {
    0,1,2,3 -> {
     if(selected.isEmpty()) Toast.makeText(this,"Select text to edit",Toast.LENGTH_SHORT).show()
     else {
      val rewritten=when(item.itemId) {
       0 -> selected.uppercase()
       1 -> selected.lowercase()
       2 -> selected.replaceFirstChar { it.titlecase() }
       else -> if(selected.lastOrNull() in listOf('.','!','?','।')) selected else "$selected."
      }
      commit(rewritten)
     }
    }
    in 11..15 -> {
     if(selected.isEmpty()) Toast.makeText(this,"Select text to rewrite",Toast.LENGTH_SHORT).show()
     else {
      val result=when(item.itemId) {
       11 -> "Please, " + selected.replaceFirstChar { it.lowercase() }.trimEnd('.', ' ') + ". Thank you."
       12 -> "Dear Sir/Madam,\n" + selected.replaceFirstChar { it.uppercase() }.trimEnd('.', ' ') + ".\nBest regards"
       13 -> "Hi! " + selected.replaceFirstChar { it.uppercase() }
       14 -> "অনুগ্রহ করে " + selected.trim().trimEnd('।', ' ') + "। ধন্যবাদ।"
       else -> if(selected.any { it in '\u0980'..'\u09ff' }) "আসসালামু আলাইকুম। " + selected else "Hello! " + selected
      }
      commit(result)
     }
    }
    else -> commit(labels[item.itemId].substringAfter(": "))
   }
   true
  }
  popup.show()
 }
 private fun showAllKeyboardTools(anchor:View) {
  val popup=PopupMenu(this,anchor)
  val items=listOf("🎨 Themes", "✦ AI tools", "▤ Clipboard", "Aa Fonts", "☻ Emoji", "🎙 Voice typing", "⌕ Search", "🌐 Change language", "− Smaller keys", "+ Larger keys", "★ Favorites", "⚙ Settings", "A− Smaller letters", "A+ Larger letters", "# * Symbols", "Banking keyboard size")
  items.forEachIndexed { index,title -> popup.menu.add(0,index,index,title) }
  popup.setOnMenuItemClickListener { item ->
   when(item.itemId) {
    0 -> showQuickThemes()
    1 -> showAiTools()
    2 -> showClipboard()
    3 -> showFonts()
    4 -> showEmoji()
    5 -> launchVoice()
    6 -> showSearchTools()
    7 -> switchLanguage()
    8 -> changeKeyHeight(-3)
    9 -> changeKeyHeight(3)
    10 -> showFavorites()
    11 -> openSettings()
    12 -> changeFontSize(-2)
    13 -> changeFontSize(2)
    14 -> { symbols=true; build() }
    15 -> showBankingSizeChooser(anchor)
   }
   true
  }
  popup.show()
 }
 private fun showBankingSizeChooser(anchor:View) {
  val popup=PopupMenu(this,anchor)
  listOf(40,50,60,70,80,95,110,132).forEach { value ->
   popup.menu.add("Banking key height: ${value}dp").setOnMenuItemClickListener {
    prefs.edit().putInt("banking_key_height",value).apply()
    if(numeric) build()
    Toast.makeText(this,"Banking size saved: ${value}dp",Toast.LENGTH_SHORT).show()
    true
   }
  }
  popup.show()
 }
 private fun showSearchTools() {
  val popup=android.widget.PopupMenu(this,board)
  popup.menu.add("Search the web").setOnMenuItemClickListener {
   try { startActivity(Intent(Intent.ACTION_WEB_SEARCH).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) }
   catch (_:Exception) { Toast.makeText(this,"Search is not available on this phone",Toast.LENGTH_SHORT).show() }
   true
  }
  popup.menu.add("Show more keyboard tools").setOnMenuItemClickListener { toolsExpanded=true; build(); true }
  popup.show()
 }
 private var speechRecognizer:SpeechRecognizer?=null
 private var voiceListening=false
 private var voiceSession=0
 private fun stopVoice() {
  voiceSession++
  voiceListening=false
  try { speechRecognizer?.cancel(); speechRecognizer?.destroy() } catch (_:Exception) {}
  speechRecognizer=null
 }
 private fun voiceLanguage():String {
  val configured=prefs.getString("voice_language","Auto")
  return when(configured) { "বাংলা" -> "bn-BD"; "English" -> "en-US"; else -> if(bangla||banglish) "bn-BD" else "en-US" }
 }
 fun startVoiceAfterPermission() { voiceHandler.post { if(!secureField) startVoiceRecognition() } }
 private fun launchVoice() {
  if(secureField) return
  if(voiceListening) { stopVoice(); Toast.makeText(this,"Voice typing stopped",Toast.LENGTH_SHORT).show(); return }
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
   try { startActivity(Intent(this,VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
   catch (_:Exception) { Toast.makeText(this,"Enable microphone permission in app settings",Toast.LENGTH_LONG).show() }
   return
  }
  startVoiceRecognition()
 }
 private fun startVoiceRecognition() {
  if(!SpeechRecognizer.isRecognitionAvailable(this)) {
   Toast.makeText(this,"Install or enable Google Speech Recognition",Toast.LENGTH_LONG).show(); return
  }
  if(currentInputConnection==null) {
   Toast.makeText(this,"Tap a text field before voice typing",Toast.LENGTH_SHORT).show(); return
  }
  stopVoice()
  val session=voiceSession
  try {
   val recognizer=SpeechRecognizer.createSpeechRecognizer(this)
   speechRecognizer=recognizer
   recognizer.setRecognitionListener(object:RecognitionListener {
    override fun onReadyForSpeech(params:Bundle?) { if(session==voiceSession) Toast.makeText(this@KeyboardService,"Listening…",Toast.LENGTH_SHORT).show() }
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB:Float) {}
    override fun onBufferReceived(buffer:ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error:Int) {
     if(session!=voiceSession) return
     stopVoice()
     val message=when(error) {
      SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap mic to retry"
      SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Tap mic to retry"
      SpeechRecognizer.ERROR_NETWORK,SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech network error"
      SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
      else -> "Voice recognition error: $error"
     }
     Toast.makeText(this@KeyboardService,message,Toast.LENGTH_SHORT).show()
    }
    override fun onResults(results:Bundle?) {
     if(session!=voiceSession) return
     val recognized=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull { it.isNotBlank() }
     // The editor retains focus because no Activity was opened for dictation.
     if(!recognized.isNullOrBlank() && !secureField) {
      val ic=currentInputConnection
      if(ic!=null) {
       ic.beginBatchEdit()
       try { ic.commitText(recognized+" ",1) } finally { ic.endBatchEdit() }
      } else {
       getSharedPreferences("voice_delivery",Context.MODE_PRIVATE).edit().putString("pending",recognized+" ").apply()
      }
     }
     stopVoice()
    }
    override fun onPartialResults(partialResults:Bundle?) {}
    override fun onEvent(eventType:Int,params:Bundle?) {}
   })
   val request=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    putExtra(RecognizerIntent.EXTRA_LANGUAGE,voiceLanguage())
    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true)
    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1)
   }
   voiceListening=true
   recognizer.startListening(request)
  } catch (e:Exception) {
   stopVoice(); Toast.makeText(this,"Voice typing unavailable: ${e.localizedMessage}",Toast.LENGTH_LONG).show()
  }
 }
 private fun showFonts() {
  if(secureField) return
  val choices=arrayOf("𝐁𝐨𝐥𝐝","𝘐𝘵𝘢𝘭𝘪𝘤","𝓢𝓬𝓻𝓲𝓹𝓽","𝔊𝔬𝔱𝔥𝔦𝔠")
  val popup=PopupMenu(this,board.getChildAt(0)); choices.forEachIndexed { i,v -> popup.menu.add(0,i,i,v) }
  popup.setOnMenuItemClickListener { item ->
   val selected=currentInputConnection?.getSelectedText(0)?.toString().orEmpty()
   if(selected.isEmpty()) Toast.makeText(this,"Select English text first",Toast.LENGTH_SHORT).show()
   else {
    val upper=intArrayOf(0x1D400,0x1D434,0x1D468,0x1D504)
    val lower=intArrayOf(0x1D41A,0x1D44E,0x1D482,0x1D51E)
    val converted=buildString {
     selected.forEach { c ->
      val cp=when(c) {
       in 'A'..'Z' -> upper[item.itemId]+(c-'A')
       in 'a'..'z' -> lower[item.itemId]+(c-'a')
       else -> 0
      }
      if(cp==0) append(c) else appendCodePoint(cp)
     }
    }
    commit(converted)
   }
   true
  }; popup.show()
 }
 private val emojiGroups=linkedMapOf(
  "Faces" to "😀 😁 😂 🤣 😃 😄 😅 😆 😉 😊 😋 😎 😍 🥰 😘 😗 😙 😚 🙂 🤗 🤩 🤔 🫡 😐 😑 😶 🙄 😏 😣 😥 😮 🤐 😯 😪 😫 🥱 😴 😌 😛 😜 🤪 😝 🤤 😒 😓 😔 😕 🥲 😢 😭 😤 😠 😡 🤬 😱 😨 😰 😳 🥺 😬 🤯 😇 🤠 🥳 🥸 😷 🤒 🤕 🤢 🤮 🤧",
  "Hands" to "👍 👎 👏 🙌 👐 🤲 🙏 🤝 ✌️ 🤞 🤟 🤘 👌 🤌 🤏 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 💪 🫶 🫰 🖕 ✍️",
  "Hearts" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💖 💗 💓 💞 💕 💘 💝 💟 ❣️ 💔 ❤️‍🔥 ❤️‍🩹 💯 ✨ ⭐ 🌟 💫 🔥 ⚡ 🎉 🎊 🎁",
  "Animals" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦋 🐝 🐞 🐢 🐍 🐬 🐳 🐠 🦀 🐙",
  "Food" to "🍎 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🥦 🌽 🥕 🍞 🥐 🧀 🍕 🍔 🍟 🌭 🍿 🍚 🍜 🍰 🎂 🍫 🍬 ☕ 🧃",
  "Objects" to "📱 💻 ⌚ 📷 🎥 🎧 🎤 🎵 🎶 🎮 🚗 🚌 ✈️ 🚀 🏠 🏡 🌍 🌎 🌏 ☀️ 🌙 🌈 ☁️ ☔ ❄️ 🌹 🌸 🌺 🌻 📚 ✏️ 💡 🔑 🔒 💰 💳",
  "New" to "🫠 🫢 🫣 🫥 🫨 🥹 🥺 🫩 🫡 🫶 🫰 🫵 🫳 🫴 🫷 🫸 🩷 🩵 🩶 🪽 🪿 🪼 🫎 🦤 🪻 🪷 🪸 🪹 🪺 🫧 🪩 🪄 🪅 🪆 🪭 🪮 🪇 🪈 🪯 🛜 🪫 🩻 🩼 🛝 🛟 🛻 🛵 🛺 🛸 🪐 🧿 🪬 🧩 🧸 🪀 🪁 🧵 🪡 🧶 🪢",
  "Arrows" to "← → ↑ ↓ ↔ ↕ ↖ ↗ ↘ ↙ ⇐ ⇒ ⇑ ⇓ ⇔ ➜ ➤ ➔ ➡ ⬅ ⬆ ⬇ ↩ ↪ ⤴ ⤵ ↺ ↻ ⏎ ⌫ ⌦ ⌘ ⌥ ⌃ ⌧",
  "Math" to "± × ÷ ≠ ≈ ≤ ≥ ∞ √ ∑ ∏ ∫ ∂ ∆ ∇ ∈ ∉ ∩ ∪ ⊂ ⊃ ∅ ∀ ∃ ∴ ∵ ° ‰ ‱ ½ ⅓ ¼ ¾ ² ³ ⁰ ¹ ₿ € £ ¥ ₹ ৳ ₩ ₽",
  "Text Faces" to "(^_^)|(≧▽≦)|(◕‿◕)|(｡◕‿◕｡)|(づ｡◕‿‿◕｡)づ|(♥‿♥)|(✿◠‿◠)|(¬‿¬)|(☞ﾟヮﾟ)☞|(╥﹏╥)|(ಥ_ಥ)|(T_T)|(╬ಠ益ಠ)|(ง'̀-'́)ง|(・_・)|(⊙_⊙)|(ʘ‿ʘ)|(ᵔᴥᵔ)|(￣▽￣)|(⌒‿⌒)|(≧◡≦)|(•̀ᴗ•́)و|(つ≧▽≦)つ|(づ￣³￣)づ|(ノಠ益ಠ)ノ|(｡♥‿♥｡)",
  "Symbols" to "✅ ❌ ✔️ ❗ ❓ ⚠️ ⛔ 🚫 ➕ ➖ ➗ ✖️ ♻️ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔥 💯 🇧🇩 🇮🇳 🇮🇹 🇺🇸 🇬🇧"
 )
 private var emojiCategory="Faces"
 private fun showEmoji() { if(secureField) return; emojiPage=true; build() }
 private fun renderEmojiPage() {
  val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  nav.addView(key("← ABC",1.5f) { emojiPage=false; build() })
  nav.addView(key("⌫") { erase() })
  board.addView(nav)
  val categories=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false }
  val categoryRow=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  emojiGroups.keys.forEach { cat -> categoryRow.addView(key(if(cat==emojiCategory) "● $cat" else cat,1.6f) { emojiCategory=cat; build() }) }
  categories.addView(categoryRow); board.addView(categories)
  val scroll=ScrollView(this).apply { isFillViewport=false }
  val grid=android.widget.GridLayout(this).apply { columnCount=if(emojiCategory=="Text Faces") 3 else 8 }
  emojiGroups[emojiCategory].orEmpty().split(if(emojiCategory=="Text Faces") "|" else " ").filter { it.isNotBlank() }.forEach { emoji ->
   val b=TextView(this).apply {
    text=emoji; textSize=if(emojiCategory=="Text Faces") 15f else 25f; gravity=android.view.Gravity.CENTER
    setOnClickListener { commit(emoji) }
   }
   grid.addView(b,android.widget.GridLayout.LayoutParams().apply {
    width=0; height=49.dp; columnSpec=android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED,1f)
   })
  }
  scroll.addView(grid); board.addView(scroll,LinearLayout.LayoutParams(-1,245.dp))
 }
 private fun showFavorites() { if(secureField) return; val items=(prefs.getString("favorites","") ?: "").split(';').filter { it.contains('|') }; if(items.isEmpty()) { Toast.makeText(this,"Add favorite numbers in keyboard settings",Toast.LENGTH_SHORT).show(); return }; val popup=PopupMenu(this,board.getChildAt(0)); items.forEachIndexed { i,item -> popup.menu.add(0,i,i,item.replace('|',' ')) }; popup.setOnMenuItemClickListener { item -> items.getOrNull(item.itemId)?.substringAfter('|')?.let { commit(it) }; true }; popup.show() }
}
