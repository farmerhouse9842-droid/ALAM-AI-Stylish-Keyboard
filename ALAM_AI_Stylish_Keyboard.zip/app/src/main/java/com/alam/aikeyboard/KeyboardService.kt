package com.alam.aikeyboard

import android.inputmethodservice.InputMethodService
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

class KeyboardService : InputMethodService() {
 private var secureField=false
 private var numeric=false
 private var shift=false
 private var bangla=false
 private var symbols=false
 private var banglish=false
 private var pending=""
 private lateinit var board:LinearLayout
 private val prefs by lazy { getSharedPreferences("keyboard",Context.MODE_PRIVATE) }
 override fun onCreateInputView():View { board=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; build(); return board }
 override fun onStartInputView(info:EditorInfo?,restarting:Boolean) { super.onStartInputView(info,restarting); val type=(info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS; numeric=type==InputType.TYPE_CLASS_NUMBER || type==InputType.TYPE_CLASS_PHONE || type==InputType.TYPE_CLASS_DATETIME; secureField=((info?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION) in listOf(InputType.TYPE_TEXT_VARIATION_PASSWORD,InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,InputType.TYPE_NUMBER_VARIATION_PASSWORD); symbols=false; shift=false; pending=""; if(::board.isInitialized) build() }
 private fun background():Drawable { val theme=prefs.getString("theme","Dark"); val colors=when(theme) { "Light"->intArrayOf(0xffe8edf4.toInt(),0xffcbd5e1.toInt()); "Neon"->intArrayOf(0xff230b52.toInt(),0xff7c1c90.toInt()); "Glass"->intArrayOf(0xff7c95b3.toInt(),0xffb7d3e6.toInt()); "3D"->intArrayOf(0xff394150.toInt(),0xff141b2b.toInt()); else->intArrayOf(0xff252b39.toInt(),0xff111827.toInt()) }; if(theme=="Photo") { try { val uri=android.net.Uri.parse(prefs.getString("photo", "")); val stream=contentResolver.openInputStream(uri); val bmp=BitmapFactory.decodeStream(stream); stream?.close(); if(bmp!=null) return BitmapDrawable(resources,bmp).apply { alpha=(prefs.getInt("opacity",35)*255/100).coerceIn(0,255); gravity=android.view.Gravity.FILL } } catch(_:Exception) {} }; return GradientDrawable(GradientDrawable.Orientation.TL_BR,colors) }
 private fun key(text:String,weight:Float=1f, action:()->Unit):Button { return Button(this).apply { this.text=text; textSize=18f; isAllCaps=false; setTextColor(Color.WHITE); background=GradientDrawable().apply { setColor(0xff48546d.toInt()); cornerRadius=14f; setStroke(2,0xff70809c.toInt()) }; setOnClickListener { action() }; layoutParams=LinearLayout.LayoutParams(0,52.dp,weight).apply { setMargins(2.dp,3.dp,2.dp,3.dp) }; minWidth=0; minHeight=0; setPadding(0,0,0,0) } }
 private val Int.dp:Int get()=(this*resources.displayMetrics.density).toInt()
 private fun row(keys:List<String>,action:(String)->Unit) { val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }; keys.forEach { k -> r.addView(key(k) { action(k) }) }; board.addView(r) }
 private fun commit(s:String) { currentInputConnection?.commitText(s,1) }
 private fun flushBanglish() { if(pending.isNotEmpty()) { currentInputConnection?.commitText(Banglish.convert(pending),1); pending="" } }
 private fun typeLetter(s:String) { if(banglish && !symbols && !numeric) { pending+=s.lowercase(); currentInputConnection?.setComposingText(Banglish.convert(pending),1) } else commit(s) }
 private fun erase() { if(banglish && pending.isNotEmpty()) { pending=pending.dropLast(1); if(pending.isEmpty()) currentInputConnection?.finishComposingText() else currentInputConnection?.setComposingText(Banglish.convert(pending),1) } else currentInputConnection?.deleteSurroundingText(1,0) }
 private fun switchLanguage() { flushBanglish(); when { banglish -> { banglish=false; bangla=true }; bangla -> { bangla=false; banglish=false }; else -> { banglish=true; bangla=false } }; build() }
 private fun build() {
  board.removeAllViews(); board.background=background(); board.setPadding(4.dp,6.dp,4.dp,8.dp)
  val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  top.addView(key(if(numeric) "123" else if(banglish) "Banglish" else if(bangla) "বাংলা" else "EN") { if(!numeric) { switchLanguage() } })
  if(!secureField) top.addView(key("★ Numbers",2f) { showFavorites() })
  top.addView(key("⚙") { val i=android.content.Intent(this,MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) })
  board.addView(top)
  if(numeric) { listOf(listOf("1","2","3"),listOf("4","5","6"),listOf("7","8","9"),listOf("*","0","#"),listOf("-",".","⌫")).forEach { row(it) { k -> when(k) { "⌫"->erase(); else->commit(k) } } }; return }
  val rows=if(symbols) listOf("1234567890","@#₹৳%&*()-","/;:!?.,") else if(bangla) listOf("ৌৈাীূবহগদজড","োে্িুপ রকতচট".replace(" ",""),"ংম নলসযষশড়".replace(" ","")) else listOf("qwertyuiop","asdfghjkl","zxcvbnm")
  rows.forEach { chars -> row(chars.map { it.toString() }) { k -> typeLetter(if(shift) k.uppercase() else k) } }
  val bottom=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  bottom.addView(key("⇧") { shift=!shift; build() }); bottom.addView(key("?123") { flushBanglish(); symbols=!symbols; build() }); bottom.addView(key("🌐") { symbols=false; switchLanguage() }); bottom.addView(key("space",3f) { flushBanglish(); commit(" ") }); bottom.addView(key("⌫") { erase() }); bottom.addView(key("↵") { flushBanglish(); if(currentInputConnection?.performEditorAction(EditorInfo.IME_ACTION_DONE)!=true) commit("\n") }); board.addView(bottom)
 }
 private fun showFavorites() { if(secureField) return; val items=(prefs.getString("favorites","") ?: "").split(';').filter { it.contains('|') }; if(items.isEmpty()) { Toast.makeText(this,"Add favorite numbers in keyboard settings",Toast.LENGTH_SHORT).show(); return }; val popup=PopupMenu(this,board.getChildAt(0)); items.forEachIndexed { i,item -> popup.menu.add(0,i,i,item.replace('|',' ')) }; popup.setOnMenuItemClickListener { item -> items.getOrNull(item.itemId)?.substringAfter('|')?.let { commit(it) }; true }; popup.show() }
}
