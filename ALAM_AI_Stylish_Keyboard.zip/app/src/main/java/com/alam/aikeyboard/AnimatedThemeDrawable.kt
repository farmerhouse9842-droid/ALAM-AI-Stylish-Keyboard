package com.alam.aikeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.SystemClock
import kotlin.math.*

/** Lightweight animated backdrop: no video decoder, networking or large bitmaps. */
class AnimatedThemeDrawable(private val style:String):Drawable() {
 private val p=Paint(Paint.ANTI_ALIAS_FLAG)
 private var phase=0f
 var animationPhase:Float=0f
  set(value) { field=value; phase=value*6.2831853f; invalidateSelf() }
 override fun onBoundsChange(bounds:android.graphics.Rect) { super.onBoundsChange(bounds); invalidateSelf() }
 override fun draw(c:Canvas) {
  val b=bounds; val w=b.width().toFloat(); val h=b.height().toFloat()
  if(w<=0f||h<=0f) return
  val colors=when(style) {
   "Animated Aurora"->intArrayOf(0xff031626.toInt(),0xff093c45.toInt(),0xff1c1545.toInt())
   "Animated Fire"->intArrayOf(0xff180305.toInt(),0xff460b07.toInt(),0xff120305.toInt())
   "Animated Galaxy"->intArrayOf(0xff050718.toInt(),0xff1a1240.toInt(),0xff070b22.toInt())
   "Animated Rain"->intArrayOf(0xff030b18.toInt(),0xff10233b.toInt(),0xff020a12.toInt())
   "Animated Hearts"->intArrayOf(0xff26051a.toInt(),0xff490d34.toInt(),0xff160519.toInt())
   else->intArrayOf(0xff061d14.toInt(),0xff10422d.toInt(),0xff06120e.toInt())
  }
  p.shader=LinearGradient(0f,0f,w,h,colors,null,Shader.TileMode.CLAMP);c.drawRect(b,p);p.shader=null
  for(i in 0 until 25) {
   val seed=i*2.39996f
   val x=((i*71.37f + sin(phase*.65f+seed)*45f)%w+w)%w
   val y=((i*59.71f + phase*(if(style=="Animated Rain") 95f else -13f))%h+h)%h
   val radius=if(style=="Animated Aurora") 24f+(i%4)*12f else 2f+(i%5)*1.3f
   val color=when(style) {
    "Animated Fire"->if(i%2==0) 0xffff3b18.toInt() else 0xffffbd42.toInt()
    "Animated Hearts"->0xffff6da5.toInt()
    "Animated Galaxy"->0xff9e91ff.toInt()
    "Animated Rain"->0xff4bbcff.toInt()
    "Animated Aurora"->if(i%2==0) 0xff00e9c5.toInt() else 0xff6a69ff.toInt()
    else->0xff8bff90.toInt()
   }
   p.color=color;p.alpha=if(style=="Animated Aurora") 35 else 105
   if(style=="Animated Rain") {p.strokeWidth=2f;c.drawLine(x,y,x-5f,y+19f,p)}
   else if(style=="Animated Hearts") {
    val r=radius*2.3f; c.drawCircle(x-r*.4f,y-r*.2f,r*.55f,p);c.drawCircle(x+r*.4f,y-r*.2f,r*.55f,p)
    val path=android.graphics.Path().apply { moveTo(x-r,y);lineTo(x,y+r);lineTo(x+r,y);close() };c.drawPath(path,p)
   } else c.drawCircle(x,y,radius,p)
  }
  p.alpha=255;p.shader=null
 }
 override fun setAlpha(alpha:Int) {p.alpha=alpha}
 override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {p.colorFilter=colorFilter}
 @Deprecated("Deprecated in Java") override fun getOpacity()=android.graphics.PixelFormat.OPAQUE
}
