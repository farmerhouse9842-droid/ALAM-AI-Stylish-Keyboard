package com.alam.aikeyboard

import android.graphics.*
import android.graphics.drawable.Drawable
import kotlin.math.*

/** Smooth, full-panel procedural theme. No network, video, or frame bitmaps. */
class AnimatedThemeDrawable(private val style:String):Drawable() {
 private val p=Paint(Paint.ANTI_ALIAS_FLAG)
 private var phase=0f
 var animationPhase:Float=0f
  set(value) { field=value; phase=value*2f*PI.toFloat(); invalidateSelf() }
 override fun draw(canvas:Canvas) {
  val b=bounds; val w=b.width().toFloat(); val h=b.height().toFloat()
  if(w<=0f||h<=0f)return
  val colors=when(style){
   "Animated Aurora"->intArrayOf(0xff041522.toInt(),0xff132448.toInt(),0xff062f32.toInt())
   "Animated Fire"->intArrayOf(0xff1a070d.toInt(),0xff441018.toInt(),0xff170811.toInt())
   "Animated Galaxy"->intArrayOf(0xff080a20.toInt(),0xff26164c.toInt(),0xff071b32.toInt())
   "Animated Rain"->intArrayOf(0xff071321.toInt(),0xff102c44.toInt(),0xff080f22.toInt())
   "Animated Hearts"->intArrayOf(0xff200b21.toInt(),0xff4b173a.toInt(),0xff140d2a.toInt())
   else->intArrayOf(0xff061d1b.toInt(),0xff143d30.toInt(),0xff071e2b.toInt())
  }
  val accent=when(style){
   "Animated Fire"->0xffff773f.toInt();"Animated Galaxy"->0xffac83ff.toInt()
   "Animated Rain"->0xff64d6ff.toInt();"Animated Hearts"->0xffff7bb5.toInt()
   "Animated Aurora"->0xff3ef6db.toInt();else->0xff88f4a3.toInt()
  }
  if(style=="Portrait Lightning") {
   drawPortraitLightning(canvas,w,h)
   return
  }
  p.alpha=255;p.style=Paint.Style.FILL
  p.shader=LinearGradient(0f,0f,w,h,colors,null,Shader.TileMode.CLAMP)
  canvas.drawRect(b,p);p.shader=null
  // Moving, soft overlapping light pools, spread across the whole keyboard.
  for(i in 0..5){
   val x=w*(.12f+(i%3)*.39f)+sin(phase*.52f+i*1.7f)*w*.19f
   val y=h*(.13f+(i/3)*.63f)+cos(phase*.43f+i*1.2f)*h*.16f
   val r=max(w,h)*(.31f+(i%3)*.035f)
   val alpha=if(i%2==0) 77 else 49
   p.shader=RadialGradient(x,y,r,intArrayOf(Color.argb(alpha,Color.red(accent),Color.green(accent),Color.blue(accent)),Color.TRANSPARENT),null,Shader.TileMode.CLAMP)
   canvas.drawCircle(x,y,r,p)
  }
  p.shader=null
  // Delicate luminous curves make the animation visible behind the keys.
  p.style=Paint.Style.STROKE
  for(i in 0..3){
   val offset=sin(phase*.55f+i*.9f)*h*.09f
   val path=Path().apply{
    moveTo(-w*.15f,h*(.14f+i*.23f)+offset)
    cubicTo(w*.25f,h*(.35f+i*.17f)-offset,w*.62f,h*(.02f+i*.25f)+offset,w*1.15f,h*(.26f+i*.20f)-offset)
   }
   p.color=accent;p.alpha=28+i*7;p.strokeWidth=2.3f+i*.8f
   canvas.drawPath(path,p)
  }
  p.style=Paint.Style.FILL
  // Floating particles are deterministic, so there are no per-frame allocations of random state.
  for(i in 0 until 52){
   val seed=i*2.399963f
   val x=((i*71.37f+sin(phase*.6f+seed)*w*.1f)%w+w)%w
   val speed=if(style=="Animated Rain")h*.86f else h*.17f
   val y=((i*53.71f+animationPhase*speed)%h+h)%h
   val r=1.1f+(i%4)*.55f
   p.color=if(i%7==0)Color.WHITE else accent
   p.alpha=if(i%7==0)150 else 76
   when(style){
    "Animated Rain"->{p.strokeWidth=1.5f;canvas.drawLine(x,y,x-5f,y+19f,p)}
    "Animated Hearts"->{val q=Path().apply{moveTo(x,y+r);cubicTo(x-3*r,y-r,x-r,y-2*r,x,y-r);cubicTo(x+r,y-2*r,x+3*r,y-r,x,y+r);close()};canvas.drawPath(q,p)}
    "Animated Fire"->canvas.drawOval(x-r,y-r*2.4f,x+r,y+r,p)
    else->canvas.drawCircle(x,y,r,p)
   }
  }
  p.alpha=255;p.shader=null;p.style=Paint.Style.FILL
 }
 /** Transparent electric arcs drawn across the full portrait, not a solid overlay. */
 private fun drawPortraitLightning(canvas:Canvas,w:Float,h:Float) {
  val t=animationPhase*2f*PI.toFloat()
  p.shader=null
  p.style=Paint.Style.STROKE
  p.strokeCap=Paint.Cap.ROUND
  for(i in 0 until 4) {
   val drift=sin(t*.75f+i*1.91f)
   val startX=w*(.08f+i*.27f)+drift*w*.055f
   val startY=h*(.04f+(i%2)*.14f)
   val bolt=Path().apply {
    moveTo(startX,startY)
    for(j in 1..8) {
     val y=startY+(h*.82f*j/8f)
     val x=startX+sin(j*2.4f+i*1.6f+t*.5f)*w*.045f+(j%2)*w*.018f
     lineTo(x,y)
    }
   }
   val flicker=(.5f+.5f*sin(t*2.1f+i*2.7f)).coerceIn(0f,1f)
   val alpha=(30+90*flicker).toInt()
   p.color=0xfffe5369.toInt();p.alpha=alpha/3;p.strokeWidth=9f
   canvas.drawPath(bolt,p)
   p.color=0xffff4a6d.toInt();p.alpha=alpha;p.strokeWidth=2.4f
   canvas.drawPath(bolt,p)
   p.color=Color.WHITE;p.alpha=(alpha*.6f).toInt();p.strokeWidth=.8f
   canvas.drawPath(bolt,p)
  }
  p.style=Paint.Style.FILL
  for(i in 0 until 18) {
   val x=((i*83.31f+sin(t+i)*w*.08f)%w+w)%w
   val y=((i*57.17f+animationPhase*h*.21f)%h+h)%h
   p.color=if(i%3==0) Color.WHITE else 0xffff5369.toInt()
   p.alpha=70+(i%4)*25
   canvas.drawCircle(x,y,1.2f+(i%3)*.6f,p)
  }
  p.alpha=255;p.shader=null;p.style=Paint.Style.FILL
 }
 override fun setAlpha(alpha:Int){p.alpha=alpha}
 override fun setColorFilter(colorFilter:ColorFilter?){p.colorFilter=colorFilter}
 @Deprecated("Deprecated in Java") override fun getOpacity()=PixelFormat.TRANSLUCENT
}
