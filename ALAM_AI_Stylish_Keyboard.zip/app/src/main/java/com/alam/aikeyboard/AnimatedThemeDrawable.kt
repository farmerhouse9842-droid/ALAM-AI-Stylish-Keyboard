package com.alam.aikeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Path
import android.graphics.drawable.Drawable
import kotlin.math.*

/** Full-height, low-allocation animated backdrop; no video or network required. */
class AnimatedThemeDrawable(private val style:String):Drawable() {
 private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
 private var t=0f
 var animationPhase:Float=0f
  set(value) { field=value; t=value*6.2831853f; invalidateSelf() }
 override fun draw(canvas:Canvas) {
  val b=bounds; val w=b.width().toFloat(); val h=b.height().toFloat()
  if(w<=0f || h<=0f) return
  val palette=when(style) {
   "Animated Aurora"->intArrayOf(0xff061a30.toInt(),0xff10224b.toInt(),0xff092b28.toInt())
   "Animated Fire"->intArrayOf(0xff240609.toInt(),0xff49120b.toInt(),0xff170514.toInt())
   "Animated Galaxy"->intArrayOf(0xff090b2a.toInt(),0xff24134b.toInt(),0xff071c38.toInt())
   "Animated Rain"->intArrayOf(0xff061b2b.toInt(),0xff102c46.toInt(),0xff050b20.toInt())
   "Animated Hearts"->intArrayOf(0xff27091d.toInt(),0xff4a1743.toInt(),0xff140d2d.toInt())
   else->intArrayOf(0xff061c17.toInt(),0xff184331.toInt(),0xff081b2c.toInt())
  }
  paint.alpha=255
  paint.shader=LinearGradient(0f,0f,w,h,palette,null,Shader.TileMode.CLAMP)
  canvas.drawRect(b,paint); paint.shader=null
  val accent=when(style) {
   "Animated Fire"->0xffff6934.toInt()
   "Animated Galaxy"->0xffa47aff.toInt()
   "Animated Rain"->0xff50cfff.toInt()
   "Animated Hearts"->0xffff6ba8.toInt()
   "Animated Aurora"->0xff38f9d7.toInt()
   else->0xff8cf9ac.toInt()
  }
  // Wide luminous bands cover the entire keyboard rather than only the toolbar.
  for(j in 0..3) {
   val cx=w*(0.15f+j*.24f)+sin(t+j*1.8f)*w*.16f
   val cy=h*(.18f+j*.23f)+cos(t*.8f+j)*h*.14f
   val r=max(w,h)*(.36f+j*.045f)
   paint.shader=RadialGradient(cx,cy,r,intArrayOf(Color.argb(65,Color.red(accent),Color.green(accent),Color.blue(accent)),Color.TRANSPARENT),null,Shader.TileMode.CLAMP)
   canvas.drawCircle(cx,cy,r,paint)
  }
  paint.shader=null
  for(i in 0 until 75) {
   val seed=i*2.399963f
   val x=((i*71.37f+sin(t*.7f+seed)*w*.12f)%w+w)%w
   val velocity=if(style=="Animated Rain") h*.85f else h*.21f
   val y=((i*53.71f+t*velocity/(2f*PI.toFloat()))%h+h)%h
   val r=1.4f+(i%5)*.75f
   paint.color=accent;paint.alpha=if(i%3==0) 160 else 85
   when(style) {
    "Animated Rain"->{ paint.strokeWidth=1.8f;canvas.drawLine(x,y,x-7f,y+24f,paint) }
    "Animated Hearts"->{
     val heart=Path().apply { moveTo(x,y+r);cubicTo(x-3*r,y-r,x-r,y-2*r,x,y-r);cubicTo(x+r,y-2*r,x+3*r,y-r,x,y+r);close() }
     canvas.drawPath(heart,paint)
    }
    "Animated Fire"->{canvas.drawOval(x-r,y-r*3f,x+r,y+r,paint)}
    else->canvas.drawCircle(x,y,r,paint)
   }
  }
  paint.alpha=255;paint.shader=null
 }
 override fun setAlpha(alpha:Int) { paint.alpha=alpha }
 override fun setColorFilter(filter:android.graphics.ColorFilter?) { paint.colorFilter=filter }
 @Deprecated("Deprecated in Java") override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT
}
