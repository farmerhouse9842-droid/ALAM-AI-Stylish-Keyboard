plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.alam.aikeyboard"; compileSdk = 35
 defaultConfig { applicationId = "com.alam.aikeyboard"; minSdk = 26; targetSdk = 35; versionCode = 43; versionName = "4.3" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
