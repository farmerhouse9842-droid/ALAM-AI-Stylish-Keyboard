plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.alam.aikeyboard"; compileSdk = 35
 defaultConfig { applicationId = "com.alam.aikeyboard"; minSdk = 26; targetSdk = 35; versionCode = 44; versionName = "4.4" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
