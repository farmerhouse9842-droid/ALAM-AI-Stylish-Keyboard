# ALAM AI Stylish Keyboard V9

Based on Styled Keys V8. Added six optional procedural animated keyboard backgrounds: Animated Aurora, Fire, Galaxy, Rain, Hearts, Forest. Select via the existing avatar > Themes menu. Animations are lightweight Canvas drawings, not external photos or videos; they do not require internet. Existing 24+ theme presets, portrait background, clipboard, banking size controls and key press effects are preserved.

Animation speed is approximately 18 fps; actual performance varies by phone. Animation pauses when the drawable is hidden. This project has not been compiled on a full Android SDK in this environment.
