# V13: Clipboard shortcut and animated themes

- Profile image remains the Function Menu button at the left of the suggestion strip.
- Clipboard shortcut (▤) now sits immediately to its right, followed by voice typing.
- Tapping clipboard opens the existing 50-item history panel.
- Animated backgrounds are driven by the keyboard animation loop even if low-memory/ambient-key effects are disabled.
- Existing V12 functions, text faces, suggestion bar, banking size and symbols are retained.

Note: Android limits background clipboard access. APK compilation and on-device validation are still required.
